let oauthCallbackClaimed = false;

export function mount(context = {}) {
  const root = context.root || document.getElementById('routePreview');
  const mode = context.mode === 'global-drawer' ? 'global-drawer' : 'settings-route';
  const isGlobal = mode === 'global-drawer';
  const api = context.api || {};
  const ui = context.ui || {};
  const utils = context.utils || {};
  const escapeHtml = utils.escapeHtml || ((value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch])));
  const formatInteger = utils.formatInteger || ((value) => new Intl.NumberFormat('zh-CN').format(Number(value) || 0));
  const fetchApi = api.fetch || (async (name, url) => {
    const response = await sessionFetch(url, { credentials: 'same-origin', cache: 'no-store' });
    const json = await response.json().catch(() => ({}));
    const ok = response.ok && json?.ok !== false;
    return { name, ok, data: json?.data ?? json, raw: json, error: ok ? null : new Error(apiErrorText(json, response.statusText)) };
  });

  const VERSION = '20260822-ai-settings-savebar-02';
  const INSTANCE_ID = `ai-${Math.random().toString(36).slice(2)}-${Date.now().toString(36)}`;
  const MODULE_CLASS = 'ai-assistant-route-host';
  const ACTIVE_CONVERSATION_KEY = 'dreamingwrt.ai.activeConversation';
  const ACTIVE_CONVERSATION_TTL = 60 * 60 * 1000;
  const wallpaper = isGlobal ? document.getElementById('appWallpaper') : null;
  const ENDPOINTS = {
    config: '/api/v1/ai/config',
    models: '/api/v1/ai/models',
    modelsSync: '/api/v1/ai/models/sync',
    providerTest: '/api/v1/ai/provider/test',
    providers: '/api/v1/ai/providers',
    dispatchPolicy: '/api/v1/ai/dispatch-policy',
    history: '/api/v1/ai/history',
    chat: '/api/v1/ai/chat',
    chatStream: '/api/v1/ai/chat/stream',
    tools: '/api/v1/ai/tools',
    toolAuthorize: '/api/v1/ai/tool-authorize',
    toolResume: '/api/v1/ai/tool-resume',
    toolResumeStream: '/api/v1/ai/tool-resume/stream',
    responses: '/api/v1/ai/responses',
    attachments: '/api/v1/ai/attachments',
    oauthProviders: '/api/v1/ai/oauth/providers',
    oauthStatus: '/api/v1/ai/oauth/status',
    oauthStart: '/api/v1/ai/oauth/start',
    oauthPoll: '/api/v1/ai/oauth/poll',
    oauthRefresh: '/api/v1/ai/oauth/refresh',
    oauthDisconnect: '/api/v1/ai/oauth/disconnect'
  };
  const PROVIDERS = [
    /*
     * `hint` 是品牌下的代表模型，只用于给磁贴一行副标题（demo 1 的 `.sub`）。
     * 它是**静态说明文本**，不是能力声明：真正可选的模型来自
     * `/api/v1/ai/models` 同步结果，别把这里的字样当成后端已支持的模型清单。
     */
    /*
     * `logo` 是固件自带的品牌图标（`/static/images/logo/`，4694 个），
     * 用户 2026-08-09：「供应商选择的小按钮卡片应该加上 logo，更直观」。
     * 只填**确认存在**的文件名，取不到图的（openai_compatible 是自建端点，
     * 没有品牌）留空，回落到 `mark` 字形，不硬塞一张不相干的图。
     */
    { id: 'openai', label: 'OpenAI', mark: 'OpenAI', hint: 'GPT 系列', logo: 'openai.svg', base: 'https://api.openai.com/v1' },
    { id: 'anthropic', label: 'Anthropic', mark: 'Claude', hint: 'Claude 系列', logo: 'claude.svg', base: 'https://api.anthropic.com' },
    { id: 'gemini', label: 'Google Gemini', mark: 'Gemini', hint: 'Gemini 系列', logo: 'gemini.svg', base: 'https://generativelanguage.googleapis.com/v1beta' },
    { id: 'kimi', label: 'Kimi Code', mark: 'Moonshot', hint: 'Kimi 系列', logo: 'kimi.svg', base: 'https://api.kimi.com/coding/v1' },
    { id: 'deepseek', label: 'DeepSeek', mark: 'DeepSeek', hint: 'DeepSeek 系列', logo: 'deepseek.svg', base: 'https://api.deepseek.com' },
    { id: 'qwen', label: '通义千问', mark: 'Qwen', hint: 'Qwen 系列', logo: 'qwen.svg', base: 'https://dashscope.aliyuncs.com/compatible-mode/v1' },
    { id: 'openai_compatible', label: 'OpenAI 兼容', mark: 'API', hint: '自建或反代端点', logo: '', base: '' }
  ];
  const OAUTH_REASON_LABELS = {
    requires_preconfigured_anthropic_workload_identity_federation: '需要预先配置 Anthropic Workload Identity Federation。',
    no_public_third_party_oauth_for_openai_model_api: 'OpenAI 模型 API 尚未开放第三方 OAuth 接入，请使用 API Key。',
    no_public_third_party_oauth_for_xai_model_api: 'xAI 模型 API 尚未开放可供第三方使用的 OAuth 接入，请使用 API Key。',
    antigravity_has_no_independent_public_model_api_oauth_contract_use_gemini: 'Antigravity 不是独立模型 API，请改用 Gemini。',
    not_connected: '尚未建立 OAuth 连接。',
    refresh_token_unavailable: '当前连接没有可用的刷新凭据，请重新授权。',
    oauth_state_mismatch: '授权回调校验失败，请重新开始授权。',
    expired_token: '本次授权已经过期，请重新开始。',
    oauth_not_pending: '没有等待完成的授权流程。',
    authorization_pending: '等待你在提供商页面确认授权。',
    poll_too_fast: '检查过于频繁，将按提供商要求稍后重试。'
  };
  const REASONING_LABELS = {
    auto: '自动', none: '关闭', minimal: '极简', low: '较低', medium: '中等', high: '较高', xhigh: '最高'
  };
  const TOOL_POLICIES = [
    ['confirm_medium', '中风险操作需确认'],
    ['read_only', '仅允许读取'],
    ['confirm_all', '所有操作均需确认']
  ];

  /*
   * 会话闸门适配器：见 dwrt-session-gate.js 的 DWRT_REQUEST。裸 fetch 会绕过 token 刷新，
   * 过期时并发请求集体拿 401，切走再切回来才恢复；走闸门可自动刷新并单次重试。
   */
  function sessionFetch(url, init = {}) {
    return window.DWRT_REQUEST ? window.DWRT_REQUEST.fetch(url, init) : fetch(url, init);
  }

  function loadOrbState() {
    try {
      const value = JSON.parse(localStorage.getItem('dreamingwrt.ai.orb') || 'null');
      return {
        x: Number.isFinite(Number(value?.x)) ? Number(value.x) : null,
        y: Number.isFinite(Number(value?.y)) ? Number(value.y) : null,
        docked: Boolean(value?.docked)
      };
    } catch (_) {
      return { x: null, y: null, docked: false };
    }
  }

  function loadActiveConversation() {
    if (!isGlobal) return { id: '', at: 0 };
    try {
      const value = JSON.parse(sessionStorage.getItem(ACTIVE_CONVERSATION_KEY) || 'null');
      const at = Number(value?.at) || 0;
      if (!firstText(value?.id) || Date.now() - at >= ACTIVE_CONVERSATION_TTL) {
        sessionStorage.removeItem(ACTIVE_CONVERSATION_KEY);
        return { id: '', at: 0 };
      }
      return { id: firstText(value.id), at };
    } catch (_) {
      return { id: '', at: 0 };
    }
  }

  const initialRequest = isGlobal ? consumeInitialRequest() : { prompt: '', autoSend: false };
  const activeConversation = loadActiveConversation();
  const state = {
    mounted: true,
    tab: isGlobal ? 'chat' : 'settings',
    settingsTab: 'overview',
    drawerOpen: Boolean(initialRequest.prompt),
    historyPage: 1,
    historyPageSize: 10,
    orb: loadOrbState(),
    orbDrag: null,
    orbClickBlockedUntil: 0,
    addMenuOpen: false,
    runtimeMenuOpen: false,
    runtimePane: 'main',
    activeConversation,
    currentTouchedAt: activeConversation.at,
    config: normalizeConfig({}),
    baseline: '',
    baselineConfig: null,
    models: [],
    modelsListed: false,
    history: [],
    historyQuery: '',
    current: newConversation(),
    prompt: initialRequest.prompt,
    initialAutoSend: initialRequest.autoSend,
    attachments: [],
    loading: true,
    historyLoading: true,
    settingsError: '',
    historyError: '',
    chatError: '',
    notice: '',
    saving: false,
    sending: false,
    syncingModels: false,
    testingProvider: false,
    /*
     * 最近一次「测试连接」的结果，供供应商页的状态卡展示联通与延迟。
     * 后端没有 last_check_* 持久列（那是多供应商契约里的设计，尚未实现），
     * 所以这是本次会话内的观测值，刷新页面即清空 —— 文案必须如实说明这一点，
     * 不能让它看起来像后端记录的历史状态。
     */
    providerCheck: { state: 'unknown', latency: 0, model: '', error: '', at: 0 },
    /*
     * 多供应商与调度策略。列表与策略都来自后端，前端不留兜底数据：
     * `loaded` 为 false 时页面说「未确认」，不说「没有」；
     * `error` 已按状态码分类（见 classifyApiFailure），不混用一句通用失败文案。
     */
    providers: { items: [], count: 0, loaded: false, loading: false, error: '', errorKind: '' },
    dispatch: { policy: null, baselineStrategy: '', draftStrategy: '', loaded: false, loading: false, error: '', errorKind: '', saving: '' },
    providerBusy: { id: '', action: '' },
    providerRemoveId: '',
    tools: [],
    toolsError: '',
    stream: {
      active: false,
      responseId: '',
      messageId: '',
      cancelling: false,
      controller: null
    },
    toolActivity: [],
    pendingAuthorizations: [],
    resume: null,
    authorizing: 0,
    resuming: false,
    oauth: {
      available: false,
      catalog: [],
      statuses: {},
      statusLoading: '',
      action: '',
      flow: null,
      confirmDisconnect: false,
      inputs: {
        gemini: {
          client_id: '',
          project_id: '',
          redirect_uri: `${window.location.origin}${window.location.pathname}`
        },
        anthropic: {
          identity_token_file: '',
          federation_rule_id: '',
          organization_id: '',
          service_account_id: '',
          workspace_id: ''
        }
      }
    },
    loadingConversation: '',
    deletingConversation: '',
    seq: 0,
    shouldStickChat: true,
    scrollPositions: {}
  };
  let oauthPollTimer = 0;

  function receiveOAuthCompletion(event) {
    if (event.origin !== window.location.origin || event.data?.type !== 'dreamingwrt:ai-oauth-complete') return;
    const provider = firstText(event.data.provider);
    if (!provider || !state.mounted) return;
    loadOAuthStatus(provider, { renderBefore: provider === state.config.provider }).then(() => notifyOAuthUpdated(provider));
  }

  async function receiveConfigUpdated(event) {
    if (event.detail?.source === INSTANCE_ID || !state.mounted) return;
    const result = await fetchApi('ai-config-update', ENDPOINTS.config);
    if (!state.mounted || !result?.ok) return;
    state.config = normalizeConfig(result.data);
    state.oauth.available = state.config.oauth.available;
    state.oauth.catalog = state.config.oauth.catalog;
    if (state.oauth.available) await loadOAuthStatus(state.config.provider, { quiet: true });
    markBaseline();
    render();
  }

  async function receiveOAuthUpdated(event) {
    if (event.detail?.source === INSTANCE_ID || !state.mounted) return;
    const provider = firstText(event.detail?.provider);
    if (!provider || !state.oauth.available) return;
    await loadOAuthStatus(provider, { quiet: true });
    if (provider === state.config.provider) render();
  }

  function notifyConfigUpdated() {
    window.dispatchEvent(new CustomEvent('dwrt:ai-config-updated', { detail: { source: INSTANCE_ID } }));
  }

  function notifyOAuthUpdated(provider) {
    window.dispatchEvent(new CustomEvent('dwrt:ai-oauth-updated', { detail: { source: INSTANCE_ID, provider } }));
  }

  window.addEventListener('message', receiveOAuthCompletion);
  window.addEventListener('dwrt:ai-config-updated', receiveConfigUpdated);
  window.addEventListener('dwrt:ai-oauth-updated', receiveOAuthUpdated);

  function consumeInitialRequest() {
    try {
      const raw = sessionStorage.getItem('dreamingwrt.ai.initialRequest');
      sessionStorage.removeItem('dreamingwrt.ai.initialRequest');
      if (!raw) return { prompt: '', autoSend: false };
      const parsed = JSON.parse(raw);
      return { prompt: firstText(parsed?.prompt).slice(0, 12000), autoSend: Boolean(parsed?.autoSend) };
    } catch (_) {
      return { prompt: '', autoSend: false };
    }
  }

  function receiveInitialRequest(event) {
    const prompt = firstText(event?.detail?.prompt).slice(0, 12000);
    if (!prompt || !state.mounted) return;
    state.prompt = prompt;
    state.initialAutoSend = Boolean(event?.detail?.autoSend);
    state.drawerOpen = true;
    setTab('chat');
    render();
    requestAnimationFrame(() => {
      const input = root.querySelector('[data-ai-prompt]');
      input?.focus();
      if (!state.loading && state.initialAutoSend && credentialReady()) {
        state.initialAutoSend = false;
        sendMessage();
      }
    });
  }

  if (isGlobal) window.addEventListener('dwrt:ai-initial-request', receiveInitialRequest);

  function syncDrawerWallpaper() {
    if (!isGlobal || !wallpaper || !root) return;
    const image = root.querySelector('[data-ai-drawer-wallpaper-image]');
    if (!image) return;
    const src = wallpaper.currentSrc || wallpaper.getAttribute('src') || '';
    if (src && image.getAttribute('src') !== src) image.setAttribute('src', src);
    const style = getComputedStyle(wallpaper);
    image.style.objectFit = style.objectFit || 'cover';
    image.style.objectPosition = style.objectPosition || '50% 50%';
    image.style.filter = style.filter || 'none';
    image.style.opacity = style.opacity || '1';
  }

  function handleWallpaperChange() {
    requestAnimationFrame(syncDrawerWallpaper);
  }

  wallpaper?.addEventListener('load', handleWallpaperChange);
  const wallpaperObserver = wallpaper && typeof MutationObserver !== 'undefined'
    ? new MutationObserver(handleWallpaperChange)
    : null;
  wallpaperObserver?.observe(wallpaper, { attributes: true, attributeFilter: ['src', 'style', 'class'] });

  function handleGlobalPointerDown(event) {
    if (!isGlobal || (!state.addMenuOpen && !state.runtimeMenuOpen)) return;
    if (event.target.closest('.ai-add-control, .ai-runtime-control')) return;
    state.addMenuOpen = false;
    state.runtimeMenuOpen = false;
    root.querySelector('.ai-add-control')?.classList.remove('is-open');
    root.querySelector('.ai-runtime-control')?.classList.remove('is-open');
    root.querySelector('.ai-add-popover')?.remove();
    root.querySelector('.ai-runtime-popover')?.remove();
    root.querySelector('[data-ai-add-toggle]')?.setAttribute('aria-expanded', 'false');
    root.querySelector('[data-ai-runtime-toggle]')?.setAttribute('aria-expanded', 'false');
  }

  if (isGlobal) document.addEventListener('pointerdown', handleGlobalPointerDown);

  function clampOrbToViewport() {
    const position = orbPosition();
    state.orb.x = position.x;
    state.orb.y = position.y;
    const orb = root?.querySelector('[data-ai-orb]');
    orb?.style.setProperty('--ai-orb-x', `${position.x}px`);
    orb?.style.setProperty('--ai-orb-y', `${position.y}px`);
    saveOrbState();
  }

  function handleViewportResize() {
    if (!state.mounted || !isGlobal) return;
    clampOrbToViewport();
  }

  if (isGlobal) window.addEventListener('resize', handleViewportResize, { passive: true });

  function setTab(value) {
    state.tab = value === 'history' && isGlobal ? 'history' : isGlobal ? 'chat' : 'settings';
  }

  function firstText(...values) {
    for (const value of values) {
      if (value === undefined || value === null) continue;
      const text = String(value).trim();
      if (text) return text;
    }
    return '';
  }

  function firstNumber(...values) {
    for (const value of values) {
      const number = Number(value);
      if (Number.isFinite(number)) return number;
    }
    return 0;
  }

  function asArray(value) {
    if (Array.isArray(value)) return value;
    if (Array.isArray(value?.items)) return value.items;
    if (Array.isArray(value?.models)) return value.models;
    if (Array.isArray(value?.conversations)) return value.conversations;
    return [];
  }

  function apiErrorText(payload, fallback = '请求失败') {
    return firstText(payload?.error?.message, payload?.error?.code, payload?.error, payload?.data?.error?.message, payload?.data?.error?.code, payload?.data?.error, payload?.message, payload?.data?.message, fallback);
  }

  function safeHttpUrl(value) {
    try {
      const url = new URL(firstText(value));
      return url.protocol === 'https:' || url.protocol === 'http:' ? url.href : '';
    } catch (_) {
      return '';
    }
  }

  function unwrap(value) {
    let current = value?.data ?? value ?? {};
    for (let i = 0; i < 3; i += 1) {
      if (!current || typeof current !== 'object' || Array.isArray(current)) break;
      if (current.data && typeof current.data === 'object') current = current.data;
      else break;
    }
    return current || {};
  }

  function normalizeConfig(value = {}) {
    const data = unwrap(value);
    const caps = data.capabilities && typeof data.capabilities === 'object' ? data.capabilities : {};
    const oauth = data.oauth && typeof data.oauth === 'object' ? data.oauth : {};
    const temperature = firstNumber(data.temperature, 0.7);
    return {
      provider: firstText(data.provider, 'openai'),
      api_base: firstText(data.api_base),
      api_key_input: '',
      api_key_set: Boolean(data.api_key_set),
      api_key_hint: firstText(data.api_key),
      clear_api_key: false,
      auth_mode: firstText(data.auth_mode, 'api_key') === 'oauth' ? 'oauth' : 'api_key',
      model: firstText(data.model, 'gpt-4o'),
      temperature: Math.max(0, Math.min(2, temperature)),
      max_tokens: Math.max(1, Math.round(firstNumber(data.max_tokens, 4096))),
      system_prompt: firstText(data.system_prompt),
      tool_policy: firstText(data.tool_policy, 'confirm_medium'),
      enabled: Boolean(data.enabled),
      reasoning_effort: firstText(data.reasoning_effort, 'auto'),
      reasoning_api_shape: firstText(data.reasoning_api_shape, caps.reasoning_api_shape, 'chat_completions'),
      capabilities: {
        reasoning_effort_supported: caps.reasoning_effort_supported !== false,
        reasoning_effort_values: asArray(caps.reasoning_effort_values).map(String),
        attachment_ids: caps.attachment_ids === true,
        attachment_upload_endpoint: firstText(caps.attachment_upload_endpoint, '/api/v1/ai/attachments'),
        chat_runtime: caps.chat_runtime === true,
        streaming: caps.streaming === true,
        streaming_ready: caps.streaming_ready === true,
        streaming_endpoint: firstText(caps.streaming_endpoint, ENDPOINTS.chatStream),
        response_cancel: caps.response_cancel === true,
        response_cancel_endpoint_template: firstText(caps.response_cancel_endpoint_template, `${ENDPOINTS.responses}/{response_id}`),
        tool_execution_loop: caps.tool_execution_loop === true,
        tool_execution_loop_streaming: caps.tool_execution_loop_streaming === true,
        tool_authorization: caps.tool_authorization === true,
        tool_authorization_resume: caps.tool_authorization_resume === true,
        tool_authorization_resume_streaming: caps.tool_authorization_resume_streaming === true,
        tool_resume_endpoint: firstText(caps.tool_resume_endpoint, ENDPOINTS.toolResume),
        tool_resume_stream_endpoint: firstText(caps.tool_resume_stream_endpoint, ENDPOINTS.toolResumeStream),
        tool_result_feedback: caps.tool_result_feedback === true,
        max_tool_rounds: Math.max(0, Math.round(firstNumber(caps.max_tool_rounds, 0))),
        provider_models_sync: caps.provider_models_sync === true,
        provider_test: caps.provider_test === true,
        /*
         * 多供应商能力位。2026-08-04 后端已交付并在 30.1 实测为 true：
         *   GET /api/v1/ai/providers        200，capabilities.multi_provider = true
         *   GET /api/v1/ai/dispatch-policy  200，available_strategies 三档
         * 这里只读能力位、不硬编码结论；能力位为假时隐藏多供应商 UI（契约第六节）。
         * 调度策略枚举一律取后端给的 dispatch_strategies，前端不自备清单。
         */
        multi_provider: caps.multi_provider === true || caps.ai_multi_provider === true,
        multi_provider_reason: firstText(caps.ai_multi_provider_reason, caps.multi_provider_reason),
        dispatch_strategies: asArray(caps.dispatch_strategies).length
          ? asArray(caps.dispatch_strategies).map(String)
          : asArray(caps.ai_dispatch_strategies).map(String),
        providers_endpoint: firstText(caps.providers_endpoint, ENDPOINTS.providers),
        dispatch_policy_endpoint: firstText(caps.dispatch_policy_endpoint, ENDPOINTS.dispatchPolicy),
        provider_last_check_persisted: caps.provider_last_check_persisted === true
      },
      oauth: {
        available: oauth.available === true,
        catalog: asArray(oauth.providers),
        status_endpoint: firstText(oauth.status_endpoint, ENDPOINTS.oauthStatus),
        start_endpoint: firstText(oauth.start_endpoint, ENDPOINTS.oauthStart),
        poll_endpoint: firstText(oauth.poll_endpoint, ENDPOINTS.oauthPoll),
        refresh_endpoint: firstText(oauth.refresh_endpoint, ENDPOINTS.oauthRefresh),
        disconnect_endpoint: firstText(oauth.disconnect_endpoint, ENDPOINTS.oauthDisconnect)
      }
    };
  }

  /*
   * 供应商列表项。字段形状见 `Backend-to-Front-llm-multi-provider-contract.md` 第三节。
   * 两条要点：
   *  - 密钥永不回显，只有 `api_key_set` 与 `api_key_hint`（前 3 后 4）。
   *  - `model_count` 为 0 且没有同步时间戳时是「未同步」，不是「0 个可用」。
   */
  function normalizeProvider(value = {}) {
    const data = value && typeof value === 'object' ? value : {};
    const check = data.last_check && typeof data.last_check === 'object' ? data.last_check : {};
    const latencyRaw = check.latency_ms ?? check.latency;
    const syncedAt = Math.round(firstNumber(data.models_synced_at, 0));
    return {
      id: firstText(data.id),
      provider: firstText(data.provider, 'openai'),
      display_name: firstText(data.display_name),
      api_base: firstText(data.api_base),
      api_key_set: Boolean(data.api_key_set),
      api_key_hint: firstText(data.api_key_hint),
      auth_mode: firstText(data.auth_mode, 'api_key') === 'oauth' ? 'oauth' : 'api_key',
      default_model: firstText(data.default_model),
      role: firstText(data.role, 'standby') === 'primary' ? 'primary' : 'standby',
      priority: Math.round(firstNumber(data.priority, 100)),
      weight: Math.max(1, Math.round(firstNumber(data.weight, 1))),
      enabled: Boolean(data.enabled),
      model_count: Math.max(0, Math.round(firstNumber(data.model_count, 0))),
      models_synced_at: syncedAt,
      last_check: {
        // -1 / null 都表示「从未测过」，与「测过且失败」必须区分。
        state: check.ok === true ? 'ok' : check.ok === false ? 'fail' : 'unknown',
        latency_ms: latencyRaw === null || latencyRaw === undefined ? null : Math.round(firstNumber(latencyRaw, 0)),
        checked_at: Math.round(firstNumber(check.checked_at, 0)),
        error: firstText(check.error),
        error_kind: firstText(check.error_kind)
      }
    };
  }

  function normalizeDispatchPolicy(value = {}) {
    const data = unwrap(value);
    const strategies = asArray(data.available_strategies).map(String).filter(Boolean);
    return {
      strategy: firstText(data.strategy, 'single'),
      // 枚举只认后端。空数组保持为空，让 UI 走「策略枚举未确认」而不是自造三档。
      available_strategies: strategies,
      failover_timeout_ms: Math.max(0, Math.round(firstNumber(data.failover_timeout_ms, 0))),
      failover_max_attempts: Math.max(0, Math.round(firstNumber(data.failover_max_attempts, 0))),
      provider_count: Math.max(0, Math.round(firstNumber(data.provider_count, 0))),
      enabled_provider_count: Math.max(0, Math.round(firstNumber(data.enabled_provider_count, 0))),
      primary_ready: data.primary_ready === true,
      updated_at: Math.round(firstNumber(data.updated_at, 0))
    };
  }

  /*
   * 失败分类。design.md「Capability truth and failure classification」第 3 条：
   * 404/405/501 是接口未实现，401 会话失效，403 权限不足，5xx 后端错误，无状态码是网络不可用。
   * `error.code` 优先于状态码，因为同一后端在不同构建下会用不同状态码表达同一件事。
   */
  function classifyApiFailure(error, subject = '数据', mode = 'read') {
    const code = firstText(error?.payload?.error?.code, error?.payload?.code);
    if (code === 'method_not_registered') return { kind: 'unimplemented', message: `${subject}对应的能力尚未接入当前固件` };
    if (code === 'source_unavailable') return { kind: 'unavailable', message: `${subject}服务暂时不可用，请稍后重试` };
    const status = Math.round(firstNumber(error?.status, 0));
    const verb = mode === 'write' ? '写入' : '读取';
    if (!status) return { kind: 'network', message: `无法连接路由器，${subject}${verb}失败` };
    if (status === 401) return { kind: 'unauthorized', message: '登录状态已失效，请重新登录' };
    // 403 必须区分读写：把写权限不足说成「无权读取」会让人以为整页都打不开。
    if (status === 403) return { kind: 'forbidden', message: mode === 'write' ? `当前账号无权修改${subject}` : `当前账号无权读取${subject}` };
    if (status === 404 || status === 405 || status === 501) return { kind: 'unimplemented', message: `${subject}接口未在当前固件实现` };
    if (status >= 500) return { kind: 'server', message: `${subject}${verb}时后端返回 ${status}` };
    return { kind: 'error', message: firstText(error?.message, `${subject}${verb}失败`) };
  }

  function configComparable(config = state.config) {
    return JSON.stringify({
      provider: config.provider,
      api_base: config.api_base,
      api_key_input: config.api_key_input,
      clear_api_key: Boolean(config.clear_api_key),
      auth_mode: config.auth_mode,
      model: config.model,
      temperature: Number(config.temperature),
      max_tokens: Number(config.max_tokens),
      system_prompt: config.system_prompt,
      tool_policy: config.tool_policy,
      enabled: Boolean(config.enabled),
      reasoning_effort: config.reasoning_effort,
      reasoning_api_shape: config.reasoning_api_shape
    });
  }

  function markBaseline() {
    state.baseline = configComparable();
    state.baselineConfig = JSON.parse(JSON.stringify(state.config));
  }

  function configDirty() {
    return Boolean(state.baseline) && state.baseline !== configComparable();
  }

  function dispatchDirty() {
    return Boolean(state.dispatch.baselineStrategy)
      && Boolean(state.dispatch.draftStrategy)
      && state.dispatch.baselineStrategy !== state.dispatch.draftStrategy;
  }

  function settingsDirty() {
    return configDirty() || dispatchDirty();
  }

  function providerDefinition(id = state.config.provider) {
    return PROVIDERS.find((item) => item.id === id) || PROVIDERS[0];
  }

  function oauthProvider(id = state.config.provider) {
    return state.oauth.catalog.find((item) => firstText(item?.provider) === id) || null;
  }

  function oauthStatus(id = state.config.provider) {
    return state.oauth.statuses[id] || null;
  }

  function credentialReady() {
    if (!state.config.enabled) return false;
    if (state.config.auth_mode !== 'oauth') return state.config.api_key_set;
    const status = oauthStatus();
    return Boolean(status?.connected) && !status?.expired;
  }

  function oauthReason(value, fallback = '') {
    const reason = firstText(value);
    return OAUTH_REASON_LABELS[reason] || fallback || reason;
  }

  function oauthProviderLabel(id) {
    return ({
      gemini: 'Google Gemini',
      kimi: 'Kimi Code',
      anthropic: 'Anthropic',
      openai: 'OpenAI',
      grok: 'Grok / xAI',
      antigravity: 'Antigravity'
    })[id] || id;
  }

  function newConversation() {
    return {
      id: '',
      title: '',
      model: '',
      reasoning_effort: '',
      tool_policy: '',
      usage: {},
      messages: []
    };
  }

  function conversationTitle() {
    return firstText(state.current.title, '新对话');
  }

  function clearActiveConversation() {
    state.activeConversation = { id: '', at: 0 };
    state.currentTouchedAt = 0;
    if (!isGlobal) return;
    try { sessionStorage.removeItem(ACTIVE_CONVERSATION_KEY); } catch (_) {}
  }

  function touchActiveConversation(id = state.current.id) {
    const conversation = firstText(id);
    if (!isGlobal || !conversation) return;
    const at = Date.now();
    state.activeConversation = { id: conversation, at };
    state.currentTouchedAt = at;
    try { sessionStorage.setItem(ACTIVE_CONVERSATION_KEY, JSON.stringify({ id: conversation, at })); } catch (_) {}
  }

  function expireInactiveConversation() {
    if (!state.current.id || !state.currentTouchedAt || Date.now() - state.currentTouchedAt < ACTIVE_CONVERSATION_TTL) return false;
    clearActiveConversation();
    state.current = newConversation();
    state.current.model = state.config.model;
    state.current.reasoning_effort = state.config.reasoning_effort;
    state.current.tool_policy = state.config.tool_policy;
    state.prompt = '';
    state.attachments = [];
    state.chatError = '';
    state.notice = '';
    state.addMenuOpen = false;
    state.runtimeMenuOpen = false;
    state.runtimePane = 'main';
    state.shouldStickChat = true;
    return true;
  }

  function normalizeMessage(value = {}, index = 0) {
    const role = firstText(value.role, value.author, 'assistant').toLowerCase();
    return {
      id: firstText(value.message_id, value.id, `${role}-${firstNumber(value.created_at, value.ts, Date.now())}-${index}`),
      role: role === 'user' ? 'user' : 'assistant',
      content: firstText(value.content, value.text, value.message),
      created_at: normalizeTimestamp(firstNumber(value.created_at, value.ts, Date.now())),
      attachments: asArray(value.attachments).map((item) => ({
        attachment_id: firstText(item.attachment_id),
        name: firstText(item.name, item.filename),
        size: firstNumber(item.size),
        type: firstText(item.type)
      }))
    };
  }

  function normalizeConversation(value = {}) {
    const data = unwrap(value);
    const item = data.item && typeof data.item === 'object' ? data.item : data;
    return {
      id: firstText(item.id),
      title: firstText(item.title, '新对话'),
      model: firstText(item.model, state.config.model),
      reasoning_effort: firstText(item.reasoning_effort, state.config.reasoning_effort),
      tool_policy: firstText(item.tool_policy, state.config.tool_policy),
      usage: item.usage && typeof item.usage === 'object' ? item.usage : {},
      messages: asArray(item.messages).map(normalizeMessage).filter((message) => message.content)
    };
  }

  function normalizeHistory(value = {}) {
    const data = unwrap(value);
    return asArray(data.items || data.conversations || data).map((item) => ({
      id: firstText(item.id),
      title: firstText(item.title, '新对话'),
      model: firstText(item.model),
      reasoning_effort: firstText(item.reasoning_effort, 'auto'),
      message_count: Math.max(0, Math.round(firstNumber(item.message_count))),
      created_at: normalizeTimestamp(firstNumber(item.created_at)),
      updated_at: normalizeTimestamp(firstNumber(item.updated_at, item.created_at)),
      usage: item.usage && typeof item.usage === 'object' ? item.usage : {}
    })).filter((item) => item.id);
  }

  function normalizeTimestamp(value) {
    const number = Number(value) || 0;
    return number > 0 && number < 100000000000 ? number * 1000 : number;
  }

  function conversationId() {
    if (state.current.id) return state.current.id;
    const random = Math.random().toString(36).slice(2, 8);
    state.current.id = `ai-web-${Date.now()}-${random}`;
    touchActiveConversation(state.current.id);
    return state.current.id;
  }

  function currentModel() {
    return firstText(state.current.model, state.config.model, state.models[0], 'gpt-4o');
  }

  function currentEffort() {
    return firstText(state.current.reasoning_effort, state.config.reasoning_effort, 'auto');
  }

  function currentToolPolicy() {
    return firstText(state.current.tool_policy, state.config.tool_policy, 'confirm_medium');
  }

  function streamingReady() {
    const caps = state.config.capabilities;
    return Boolean(caps.streaming && caps.streaming_ready && streamEndpoint());
  }

  function streamEndpoint() {
    return firstText(state.config.capabilities.streaming_endpoint, ENDPOINTS.chatStream);
  }

  function resumeEndpoint(streaming) {
    const caps = state.config.capabilities;
    return streaming
      ? firstText(caps.tool_resume_stream_endpoint, ENDPOINTS.toolResumeStream)
      : firstText(caps.tool_resume_endpoint, ENDPOINTS.toolResume);
  }

  function cancelEndpoint(responseId) {
    const id = firstText(responseId);
    if (!id) return '';
    const template = firstText(state.config.capabilities.response_cancel_endpoint_template);
    if (template.includes('{response_id}')) return template.replace('{response_id}', encodeURIComponent(id));
    return `${ENDPOINTS.responses}/${encodeURIComponent(id)}`;
  }

  function toolLabel(id) {
    const tool = state.tools.find((item) => item.id === firstText(id));
    return firstText(tool?.label, tool?.title, id, '未知工具');
  }

  function toolDefinition(id) {
    return state.tools.find((item) => item.id === firstText(id)) || null;
  }

  function normalizeTool(value = {}) {
    return {
      id: firstText(value.id, value.tool, value.name),
      label: firstText(value.label, value.title, value.display_name, value.id, value.tool, value.name),
      description: firstText(value.description, value.summary),
      risk_level: firstText(value.risk_level, value.risk, 'low'),
      category: firstText(value.category, value.group),
      enabled: value.enabled !== false
    };
  }

  function riskLabel(value) {
    return ({ low: '低风险', medium: '中风险', high: '高风险', blocked: '已禁止' })[firstText(value, 'low')] || firstText(value, 'low');
  }

  function riskTone(value) {
    const risk = firstText(value, 'low');
    if (risk === 'high' || risk === 'blocked') return 'danger';
    if (risk === 'medium') return 'warning';
    return 'info';
  }

  function normalizeToolExecution(value = {}, fallbackStatus = 'completed') {
    const execution = unwrap(value.execution ?? value);
    return {
      tool_call_id: firstText(value.tool_call_id, execution.tool_call_id),
      tool: firstText(value.tool, execution.tool),
      parameters: value.parameters && typeof value.parameters === 'object' ? value.parameters : {},
      status: firstText(execution.status, value.status, fallbackStatus),
      auth_id: firstNumber(execution.auth_id, value.auth_id, 0),
      risk_level: firstText(execution.risk_level, value.risk_level, 'low'),
      required_role: firstText(execution.required_role, value.required_role),
      error: firstText(execution.error?.message, execution.error?.code, execution.error, value.error)
    };
  }

  function recordToolActivity(entry = {}, fallbackStatus = 'completed') {
    const normalized = normalizeToolExecution(entry, fallbackStatus);
    if (!normalized.tool && !normalized.tool_call_id) return;
    const index = state.toolActivity.findIndex((item) => item.tool_call_id && item.tool_call_id === normalized.tool_call_id);
    if (index >= 0) state.toolActivity[index] = { ...state.toolActivity[index], ...normalized };
    else state.toolActivity.push(normalized);
  }

  function clearToolRuntime() {
    state.toolActivity = [];
    state.pendingAuthorizations = [];
    state.resume = null;
  }

  async function loadTools(options = {}) {
    if (!state.config.capabilities.tool_execution_loop) {
      state.tools = [];
      return;
    }
    const result = await fetchApi('ai-tools', ENDPOINTS.tools);
    if (!state.mounted) return;
    if (result?.ok) {
      const data = unwrap(result.data);
      state.tools = asArray(data.tools || data).map(normalizeTool).filter((item) => item.id);
      state.toolsError = '';
    } else {
      state.tools = [];
      state.toolsError = result?.error?.message || '无法读取工具注册表';
    }
    if (options.render !== false) render();
  }

  function streamingMessage() {
    if (!state.stream.messageId) return null;
    return state.current.messages.find((item) => item.id === state.stream.messageId) || null;
  }

  function ensureStreamingMessage() {
    let message = streamingMessage();
    if (message) return message;
    message = { id: `assistant-${Date.now()}`, role: 'assistant', content: '', created_at: Date.now(), attachments: [], streaming: true };
    state.stream.messageId = message.id;
    state.current.messages.push(message);
    render();
    return message;
  }

  function appendStreamDelta(delta) {
    const text = String(delta ?? '');
    if (!text) return;
    const message = ensureStreamingMessage();
    message.content += text;
    const node = root.querySelector(`[data-ai-message-body="${message.id}"]`);
    if (node) {
      node.innerHTML = `${escapeHtml(message.content).replace(/\n/g, '<br>')}<span class="ai-stream-caret" aria-hidden="true"></span>`;
      const chat = root.querySelector('[data-ai-scroll="chat"]');
      if (chat && chat.scrollHeight - chat.scrollTop - chat.clientHeight < 160) chat.scrollTop = chat.scrollHeight;
    } else {
      state.shouldStickChat = true;
      render();
    }
  }

  function finishStreamingMessage() {
    const message = streamingMessage();
    if (message) {
      message.streaming = false;
      if (!firstText(message.content)) {
        const index = state.current.messages.indexOf(message);
        if (index >= 0) state.current.messages.splice(index, 1);
      }
    }
    state.stream.messageId = '';
  }

  async function streamRequest(url, body, handlers = {}) {
    const controller = new AbortController();
    state.stream.controller = controller;
    const response = await sessionFetch(`${url}${url.includes('?') ? '&' : '?'}v=${encodeURIComponent(VERSION)}`, {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      signal: controller.signal,
      headers: {
        ...(api.authHeaders ? api.authHeaders() : {}),
        'Content-Type': 'application/json',
        Accept: 'text/event-stream'
      },
      body: JSON.stringify(body || {})
    });
    const contentType = firstText(response.headers.get('content-type'));
    if (!response.ok || !contentType.includes('text/event-stream')) {
      const text = await response.text().catch(() => '');
      let json = {};
      if (text) { try { json = JSON.parse(text); } catch (_) { json = {}; } }
      const error = new Error(apiErrorText(json, `流式接口返回 ${response.status}`));
      error.status = response.status;
      error.payload = json;
      error.notStream = !contentType.includes('text/event-stream');
      throw error;
    }
    if (!response.body?.getReader) {
      const error = new Error('当前浏览器不支持流式读取');
      error.notStream = true;
      throw error;
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let boundary = buffer.indexOf('\n\n');
      while (boundary >= 0) {
        const frame = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        const event = parseStreamFrame(frame);
        if (event) handlers.onEvent?.(event.name, event.payload);
        boundary = buffer.indexOf('\n\n');
      }
    }
    if (buffer.trim()) {
      const event = parseStreamFrame(buffer);
      if (event) handlers.onEvent?.(event.name, event.payload);
    }
  }

  function parseStreamFrame(frame) {
    const lines = String(frame || '').split('\n');
    let name = 'message';
    const dataLines = [];
    lines.forEach((line) => {
      if (line.startsWith('event:')) name = line.slice(6).trim();
      else if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
    });
    if (!dataLines.length) return null;
    try {
      return { name, payload: JSON.parse(dataLines.join('\n')) };
    } catch (_) {
      return { name, payload: {} };
    }
  }

  function handleStreamEvent(name, payload = {}) {
    if (!state.mounted) return;
    const conversation = firstText(payload.conversation_id);
    if (conversation) {
      state.current.id = conversation;
      touchActiveConversation();
    }
    if (firstText(payload.response_id)) state.stream.responseId = firstText(payload.response_id);
    switch (name) {
      case 'response.started':
        ensureStreamingMessage();
        break;
      case 'response.delta':
        appendStreamDelta(payload.delta);
        break;
      case 'tool.call.started':
        recordToolActivity(payload.tool_call || payload.tool_execution || payload, 'running');
        render();
        break;
      case 'tool.call.completed':
      case 'tool.call.result':
      case 'tool.call.requires_action':
        recordToolActivity(payload.tool_call || payload.tool_execution || payload);
        render();
        break;
      case 'response.requires_action':
        state.pendingAuthorizations = asArray(payload.pending_authorizations).map(normalizeToolExecution).filter((item) => item.auth_id > 0);
        asArray(payload.tool_executions).forEach(recordToolActivity);
        state.resume = {
          token: firstText(payload.resume_token),
          expires_at: firstNumber(payload.resume_expires_at, 0),
          endpoint: firstText(payload.resume_endpoint, ENDPOINTS.toolResume),
          stream_endpoint: firstText(payload.resume_stream_endpoint, ENDPOINTS.toolResumeStream)
        };
        finishStreamingMessage();
        render();
        break;
      case 'response.completed':
        applyCompletion(payload);
        break;
      case 'response.cancelled':
        applyCancellation(payload);
        break;
      case 'response.failed':
        throw new Error(apiErrorText(payload, '模型响应失败'));
      default:
        break;
    }
  }

  function applyCompletion(payload = {}) {
    const reply = extractAssistantReply(payload);
    const message = streamingMessage();
    if (message) {
      if (reply && reply.length >= message.content.length) message.content = reply;
      message.streaming = false;
      state.stream.messageId = '';
    } else if (reply) {
      state.current.messages.push({ id: `assistant-${Date.now()}`, role: 'assistant', content: reply, created_at: Date.now(), attachments: [] });
    }
    state.current.title = firstText(payload.conversation_title, state.current.title);
    if (payload.usage && typeof payload.usage === 'object') state.current.usage = payload.usage;
    asArray(payload.tool_executions).forEach(recordToolActivity);
    state.pendingAuthorizations = [];
    state.resume = null;
  }

  function applyCancellation(payload = {}) {
    const partial = firstText(payload.partial_reply);
    const message = streamingMessage();
    if (message) {
      if (partial && partial.length > message.content.length) message.content = partial;
      message.streaming = false;
      state.stream.messageId = '';
    }
    state.notice = '已停止本次回答';
  }

  async function cancelStream() {
    const responseId = firstText(state.stream.responseId);
    if (!state.stream.active || state.stream.cancelling) return;
    state.stream.cancelling = true;
    render();
    try {
      if (state.config.capabilities.response_cancel && responseId) {
        await requestJson(cancelEndpoint(responseId), { method: 'DELETE' });
      } else {
        state.stream.controller?.abort();
      }
    } catch (error) {
      state.stream.controller?.abort();
      state.chatError = error?.message || '无法停止当前回答';
    } finally {
      state.stream.cancelling = false;
      if (state.mounted) render();
    }
  }

  async function authorizeTool(authId, approve) {
    const id = Number(authId) || 0;
    if (!id || state.authorizing || state.resuming) return;
    state.authorizing = id;
    state.chatError = '';
    render();
    const streaming = streamingReady() && state.config.capabilities.tool_authorization_resume_streaming;
    try {
      const result = await postJson(ENDPOINTS.toolAuthorize, {
        id,
        approve: Boolean(approve),
        defer_continuation: streaming
      });
      if (!state.mounted) return;
      const data = unwrap(result);
      const continuation = data.continuation && typeof data.continuation === 'object' ? data.continuation : {};
      state.pendingAuthorizations = state.pendingAuthorizations.filter((item) => item.auth_id !== id);
      recordToolActivity({
        ...(state.toolActivity.find((item) => item.auth_id === id) || {}),
        auth_id: id,
        status: approve ? 'authorized' : 'denied'
      });
      const continuationStatus = firstText(continuation.status);
      const token = firstText(continuation.resume_token, state.resume?.token);
      if (state.pendingAuthorizations.length) {
        state.authorizing = 0;
        render();
        return;
      }
      if (continuationStatus === 'ready_to_resume' && token) {
        state.authorizing = 0;
        await resumeToolLoop(token);
        return;
      }
      if (continuationStatus === 'not_available') {
        state.chatError = '工具续跑状态已过期，请重新发送消息';
        state.resume = null;
      } else if (continuationStatus === 'awaiting_original_actor') {
        state.notice = '已提交授权，等待原发起会话继续';
      } else if (continuation.reply || continuation.tool_executions || continuation.pending_authorizations) {
        consumeResumeResult(continuation);
      } else if (!approve) {
        state.notice = '已拒绝该工具调用';
        state.resume = null;
      }
      state.authorizing = 0;
      finishStreamingMessage();
      await persistCurrentConversation().catch(() => {});
      render();
    } catch (error) {
      if (!state.mounted) return;
      state.authorizing = 0;
      state.chatError = error?.message || '工具授权失败';
      render();
    }
  }

  async function resumeToolLoop(token) {
    const resumeToken = firstText(token, state.resume?.token);
    if (!resumeToken || state.resuming) return;
    state.resuming = true;
    state.stream.active = true;
    state.chatError = '';
    render();
    const streaming = streamingReady() && state.config.capabilities.tool_authorization_resume_streaming;
    try {
      if (streaming) {
        await streamRequest(resumeEndpoint(true), { resume_token: resumeToken }, {
          onEvent: (name, payload) => handleStreamEvent(name, payload)
        });
      } else {
        const result = await postJson(resumeEndpoint(false), { resume_token: resumeToken });
        if (!state.mounted) return;
        consumeResumeResult(unwrap(result));
      }
      if (!state.mounted) return;
      finishStreamingMessage();
      if (!state.pendingAuthorizations.length) {
        await persistCurrentConversation();
        state.notice = '对话已保存';
      }
    } catch (error) {
      if (!state.mounted) return;
      if (error?.name !== 'AbortError') state.chatError = error?.message || '工具续跑失败';
      finishStreamingMessage();
    } finally {
      if (!state.mounted) return;
      state.resuming = false;
      state.stream.active = false;
      state.stream.controller = null;
      state.shouldStickChat = true;
      render();
    }
  }

  function consumeResumeResult(data = {}) {
    state.current.id = firstText(data.conversation_id, state.current.id);
    state.current.title = firstText(data.conversation_title, data.title, state.current.title);
    asArray(data.tool_executions).forEach(recordToolActivity);
    const pending = asArray(data.pending_authorizations).map(normalizeToolExecution).filter((item) => item.auth_id > 0);
    state.pendingAuthorizations = pending;
    if (pending.length) {
      state.resume = {
        token: firstText(data.resume_token, state.resume?.token),
        expires_at: firstNumber(data.resume_expires_at, state.resume?.expires_at, 0),
        endpoint: firstText(data.resume_endpoint, ENDPOINTS.toolResume),
        stream_endpoint: firstText(data.resume_stream_endpoint, ENDPOINTS.toolResumeStream)
      };
    } else {
      state.resume = null;
    }
    const reply = extractAssistantReply(data);
    if (reply) {
      const message = streamingMessage();
      if (message) {
        message.content = reply;
        message.streaming = false;
        state.stream.messageId = '';
      } else {
        state.current.messages.push({ id: `assistant-${Date.now()}`, role: 'assistant', content: reply, created_at: Date.now(), attachments: [] });
      }
    }
    if (data.usage && typeof data.usage === 'object') state.current.usage = data.usage;
    touchActiveConversation();
  }

  /*
   * 供应商列表与调度策略。**先请求端点，再依据响应决定渲染**（design.md 第 2 条）：
   * 不拿 `/api/v1/ai/config` 的能力位当前置门，资源端点自己才是它可用性的权威。
   * 因此这两个请求无条件发出，即便 config 那边没声明 multi_provider。
   */
  async function loadProviders(options = {}) {
    if (isGlobal) return null;
    state.providers.loading = true;
    if (options.render !== false) render();
    try {
      const data = unwrap(await requestJson(ENDPOINTS.providers));
      if (!state.mounted) return null;
      const items = asArray(data.providers).map(normalizeProvider).filter((item) => item.id);
      state.providers = {
        items,
        // 条数以后端 count 为准；缺字段时才退回数组长度。
        count: Math.max(0, Math.round(firstNumber(data.count, items.length))),
        loaded: true,
        loading: false,
        error: '',
        errorKind: ''
      };
      if (data.capabilities && typeof data.capabilities === 'object') {
        const caps = data.capabilities;
        state.config.capabilities.multi_provider = caps.multi_provider === true || caps.ai_multi_provider === true;
        const strategies = asArray(caps.dispatch_strategies).length ? asArray(caps.dispatch_strategies) : asArray(caps.ai_dispatch_strategies);
        if (strategies.length) state.config.capabilities.dispatch_strategies = strategies.map(String);
        state.config.capabilities.provider_last_check_persisted = caps.provider_last_check_persisted === true;
      }
    } catch (error) {
      if (!state.mounted) return null;
      const classified = classifyApiFailure(error, '供应商列表');
      state.providers = { items: [], count: 0, loaded: false, loading: false, error: classified.message, errorKind: classified.kind };
    }
    if (options.render !== false) render();
    return state.providers;
  }

  async function loadDispatchPolicy(options = {}) {
    if (isGlobal) return null;
    state.dispatch.loading = true;
    if (options.render !== false) render();
    try {
      const policy = normalizeDispatchPolicy(await requestJson(ENDPOINTS.dispatchPolicy));
      if (!state.mounted) return null;
      const previousDraft = state.dispatch.draftStrategy;
      const previousBaseline = state.dispatch.baselineStrategy;
      const preserveDraft = Boolean(previousBaseline && previousDraft && previousDraft !== previousBaseline);
      state.dispatch = {
        policy,
        baselineStrategy: policy.strategy,
        draftStrategy: preserveDraft ? previousDraft : policy.strategy,
        loaded: true,
        loading: false,
        error: '',
        errorKind: '',
        saving: ''
      };
    } catch (error) {
      if (!state.mounted) return null;
      const classified = classifyApiFailure(error, '调度策略');
      state.dispatch = { ...state.dispatch, policy: null, loaded: false, loading: false, error: classified.message, errorKind: classified.kind, saving: '' };
    }
    if (options.render !== false) render();
    return state.dispatch;
  }

  async function loadInitial() {
    const seq = ++state.seq;
    state.loading = true;
    state.historyLoading = true;
    render();
    const [configResult, modelsResult, historyResult] = await Promise.all([
      fetchApi('ai-config', ENDPOINTS.config),
      fetchApi('ai-models', ENDPOINTS.models),
      isGlobal ? fetchApi('ai-history', `${ENDPOINTS.history}?limit=100&offset=0`) : Promise.resolve({ ok: true, data: [] })
    ]);
    if (!state.mounted || seq !== state.seq) return;
    if (configResult?.ok) {
      state.config = normalizeConfig(configResult.data);
      state.oauth.available = state.config.oauth.available;
      state.oauth.catalog = state.config.oauth.catalog;
      state.settingsError = '';
      markBaseline();
    } else {
      state.settingsError = configResult?.error?.message || '无法读取 AI 接入配置';
      markBaseline();
    }
    if (modelsResult?.ok) {
      state.models = uniqueModels(asArray(unwrap(modelsResult.data).models || unwrap(modelsResult.data)));
      // 后端真的给了列表才算已同步；下面的兜底只是让下拉框有东西可选，
      // 概览不能把它说成「已同步 1 个模型」。
      state.modelsListed = state.models.length > 0;
    }
    if (!state.models.length) state.models = uniqueModels([state.config.model]);
    /*
     * 必须排在 `state.config = normalizeConfig(...)` 之后：`loadProviders` 会用
     * `/ai/providers` 自带的 capabilities 覆盖能力位，先跑会被这里的赋值冲掉。
     * 设置路由才需要，全局对话抽屉不拉。
     */
    if (!isGlobal) await Promise.all([loadProviders({ render: false }), loadDispatchPolicy({ render: false })]);
    if (!state.mounted || seq !== state.seq) return;
    if (historyResult?.ok) {
      state.history = normalizeHistory(historyResult.data);
      state.historyError = '';
    } else {
      state.history = [];
      state.historyError = historyResult?.error?.message || '无法读取历史对话';
    }
    state.loading = false;
    state.historyLoading = false;
    if (state.config.capabilities.tool_execution_loop) loadTools({ render: false });
    if (state.oauth.available && state.config.provider) await loadOAuthStatus(state.config.provider, { quiet: true });
    await consumeOAuthCallback();
    const resumeId = firstText(state.activeConversation.id);
    if (isGlobal && resumeId && state.history.some((item) => item.id === resumeId)) {
      await openHistory(resumeId, { quiet: true });
    } else if (resumeId) {
      clearActiveConversation();
      render();
    } else {
      render();
    }
    if (state.prompt) requestAnimationFrame(() => {
      const prompt = root.querySelector('[data-ai-prompt]');
      prompt?.focus();
      if (state.initialAutoSend && credentialReady()) {
        state.initialAutoSend = false;
        sendMessage();
      }
    });
  }

  function clearOAuthPollTimer() {
    if (!oauthPollTimer) return;
    window.clearTimeout(oauthPollTimer);
    oauthPollTimer = 0;
  }

  function scheduleOAuthPoll(seconds) {
    clearOAuthPollTimer();
    const delay = Math.max(1, firstNumber(seconds, state.oauth.flow?.poll_after_seconds, state.oauth.flow?.interval, 5));
    oauthPollTimer = window.setTimeout(() => pollOAuth(), delay * 1000);
  }

  async function loadOAuthStatus(provider = state.config.provider, options = {}) {
    if (!provider || !state.oauth.available) return null;
    if (!options.quiet) {
      state.oauth.statusLoading = provider;
      if (options.renderBefore) render();
    }
    try {
      const result = await requestJson(`${state.config.oauth.status_endpoint}?provider=${encodeURIComponent(provider)}`);
      const status = unwrap(result);
      state.oauth.statuses[provider] = status;
      if (status.pending && provider === 'kimi' && state.oauth.flow?.provider === 'kimi') {
        scheduleOAuthPoll(state.oauth.flow.poll_after_seconds);
      }
      return status;
    } catch (error) {
      if (!options.quiet) state.settingsError = error?.message || '无法读取 OAuth 状态';
      return null;
    } finally {
      if (!options.quiet) {
        state.oauth.statusLoading = '';
        render();
      }
    }
  }

  function oauthStartPayload(provider) {
    if (provider === 'gemini') {
      const values = state.oauth.inputs.gemini;
      const redirectUri = firstText(values.redirect_uri, `${window.location.origin}${window.location.pathname}`);
      if (!firstText(values.client_id) || !firstText(values.project_id) || !redirectUri) {
        throw new Error('请填写 Google Client ID、Project ID 和回调地址');
      }
      return { provider, client_id: values.client_id.trim(), project_id: values.project_id.trim(), redirect_uri: redirectUri.trim() };
    }
    if (provider === 'anthropic') {
      const values = state.oauth.inputs.anthropic;
      for (const key of ['identity_token_file', 'federation_rule_id', 'organization_id', 'service_account_id']) {
        if (!firstText(values[key])) throw new Error('请填写完整的 Anthropic WIF 配置');
      }
      return Object.fromEntries([['provider', provider], ...Object.entries(values).filter(([, value]) => firstText(value)).map(([key, value]) => [key, value.trim()])]);
    }
    return { provider };
  }

  async function startOAuth() {
    const provider = state.config.provider;
    if (state.oauth.action || oauthProvider(provider)?.supported !== true) return;
    clearOAuthPollTimer();
    state.oauth.action = `${provider}:start`;
    state.settingsError = '';
    state.notice = '';
    render();
    try {
      const result = unwrap(await postJson(state.config.oauth.start_endpoint, oauthStartPayload(provider)));
      state.oauth.flow = { ...result, provider };
      if (provider === 'gemini') {
        const url = safeHttpUrl(result.authorization_url);
        if (!url) throw new Error('后端没有返回 Google 授权地址');
        const popup = window.open(url, 'dreamingwrt-gemini-oauth', 'popup=yes,width=720,height=820');
        if (!popup) window.location.assign(url);
        else popup.focus();
        state.notice = 'Google 授权页面已打开';
      } else if (provider === 'kimi') {
        const url = safeHttpUrl(firstText(result.verification_uri_complete, result.verification_uri));
        if (url) window.open(url, 'dreamingwrt-kimi-oauth', 'popup=yes,width=720,height=820')?.focus();
        scheduleOAuthPoll(result.poll_after_seconds);
      } else if (provider === 'anthropic' && result.connected) {
        state.notice = 'Anthropic WIF 已连接';
        notifyOAuthUpdated(provider);
      }
      await loadOAuthStatus(provider, { quiet: true });
    } catch (error) {
      state.settingsError = oauthReason(error?.payload?.error, error?.message || 'OAuth 授权启动失败');
    }
    state.oauth.action = '';
    render();
  }

  async function pollOAuth(payload = {}) {
    const provider = firstText(payload.provider, state.oauth.flow?.provider, state.config.provider);
    if (!provider || state.oauth.action === `${provider}:poll`) return;
    let shouldRender = false;
    state.oauth.action = `${provider}:poll`;
    try {
      const result = unwrap(await postJson(state.config.oauth.poll_endpoint, { provider, ...payload }));
      state.oauth.statuses[provider] = { ...(state.oauth.statuses[provider] || {}), ...result, pending: false };
      state.oauth.flow = null;
      if (provider === state.config.provider) state.notice = `${oauthProviderLabel(provider)} 已连接`;
      notifyOAuthUpdated(provider);
      clearOAuthPollTimer();
      shouldRender = true;
    } catch (error) {
      const code = firstText(error?.payload?.error?.code, error?.payload?.error, error?.payload?.data?.error);
      const retry = firstNumber(error?.payload?.retry_after_seconds, error?.payload?.data?.retry_after_seconds, state.oauth.flow?.poll_after_seconds, 5);
      if (error?.status === 202 || error?.status === 429 || code === 'authorization_pending' || code === 'slow_down' || code === 'poll_too_fast') {
        scheduleOAuthPoll(retry);
      } else {
        clearOAuthPollTimer();
        state.settingsError = oauthReason(code, error?.message || 'OAuth 授权检查失败');
        shouldRender = true;
      }
    }
    state.oauth.action = '';
    if (state.mounted && shouldRender) render();
  }

  function callbackParameters() {
    const url = new URL(window.location.href);
    const hashParams = new URLSearchParams((url.hash.split('?')[1] || '').replace(/^\?/, ''));
    return {
      code: firstText(url.searchParams.get('code'), hashParams.get('code')),
      state: firstText(url.searchParams.get('state'), hashParams.get('state')),
      error: firstText(url.searchParams.get('error'), hashParams.get('error'))
    };
  }

  function stripOAuthCallbackFromUrl() {
    const url = new URL(window.location.href);
    ['code', 'state', 'error', 'error_description', 'scope'].forEach((key) => url.searchParams.delete(key));
    if (url.hash.includes('?')) {
      const [route, query] = url.hash.split('?');
      const params = new URLSearchParams(query);
      ['code', 'state', 'error', 'error_description', 'scope'].forEach((key) => params.delete(key));
      url.hash = params.toString() ? `${route}?${params}` : route;
    }
    window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
  }

  async function consumeOAuthCallback() {
    const callback = callbackParameters();
    if ((!callback.code && !callback.error) || oauthCallbackClaimed) return;
    oauthCallbackClaimed = true;
    try {
      if (callback.error) throw new Error(callback.error);
      if (!callback.state) throw new Error('Google OAuth 回调缺少 state');
      const result = unwrap(await postJson(state.config.oauth.poll_endpoint, { provider: 'gemini', code: callback.code, state: callback.state }));
      state.oauth.statuses.gemini = { ...(state.oauth.statuses.gemini || {}), ...result, pending: false };
      state.oauth.flow = null;
      state.notice = 'Google Gemini 已连接';
      notifyOAuthUpdated('gemini');
      window.opener?.postMessage({ type: 'dreamingwrt:ai-oauth-complete', provider: 'gemini' }, window.location.origin);
      if (window.opener && !window.opener.closed) window.setTimeout(() => window.close(), 650);
    } catch (error) {
      state.settingsError = oauthReason(error?.payload?.error, error?.message || 'Google OAuth 回调处理失败');
    } finally {
      stripOAuthCallbackFromUrl();
      render();
    }
  }

  async function refreshOAuth() {
    const provider = state.config.provider;
    if (state.oauth.action || !oauthStatus(provider)?.connected) return;
    state.oauth.action = `${provider}:refresh`;
    state.settingsError = '';
    render();
    try {
      const result = unwrap(await postJson(state.config.oauth.refresh_endpoint, { provider }));
      state.oauth.statuses[provider] = { ...(state.oauth.statuses[provider] || {}), ...result, expired: false };
      state.notice = 'OAuth 凭据已刷新';
      notifyOAuthUpdated(provider);
    } catch (error) {
      state.settingsError = oauthReason(error?.payload?.error, error?.message || 'OAuth 凭据刷新失败');
    }
    state.oauth.action = '';
    render();
  }

  async function disconnectOAuth() {
    const provider = state.config.provider;
    if (state.oauth.action) return;
    clearOAuthPollTimer();
    state.oauth.confirmDisconnect = false;
    state.oauth.action = `${provider}:disconnect`;
    state.settingsError = '';
    render();
    try {
      await postJson(state.config.oauth.disconnect_endpoint, { provider });
      state.oauth.statuses[provider] = { ...(state.oauth.statuses[provider] || {}), connected: false, pending: false, expired: false, expires_at: 0 };
      state.oauth.flow = null;
      state.notice = 'OAuth 连接已断开';
      notifyOAuthUpdated(provider);
    } catch (error) {
      state.settingsError = error?.message || '断开 OAuth 连接失败';
    }
    state.oauth.action = '';
    render();
  }

  function uniqueModels(values) {
    const out = [];
    const seen = new Set();
    values.forEach((value) => {
      const model = firstText(value?.id, value?.name, value);
      if (!model || seen.has(model)) return;
      seen.add(model);
      out.push(model);
    });
    return out;
  }

  function render() {
    if (!root || !state.mounted) return;
    const snapshot = captureViewState();
    root.className = `${root.className.split(/\s+/).filter((item) => item && item !== MODULE_CLASS).join(' ')} ${MODULE_CLASS}`.trim();
    root.hidden = false;
    root.classList.toggle('ai-global-host', isGlobal);
    root.classList.toggle('ai-settings-route-host', !isGlobal);
    root.innerHTML = isGlobal ? globalMarkup() : `<main class="ai-assistant-shell ai-settings-route-shell"><header class="ai-settings-route-header">${settingsTabsMarkup()}</header><div class="ai-view-host">${settingsView()}</div>${settingsSavebarMarkup()}</main>`;
    ui.mountAll?.(root);
    bindEvents();
    if (isGlobal) bindGlobalEvents();
    restoreViewState(snapshot);
    if (isGlobal) {
      syncDrawerWallpaper();
      ui.scheduleAdaptiveForegroundSample?.(80, root);
    }
    else {
      ui.scheduleAdaptiveForegroundSample?.(80, root);
      ui.scheduleGlassCardsRender?.(120);
    }
  }

  function globalMarkup() {
    const position = orbPosition();
    return `<div class="ai-global-layer ${state.drawerOpen ? 'is-open' : ''} ${state.orb.docked ? 'is-docked' : ''}">
      <button class="ai-floating-orb" type="button" data-ai-orb aria-label="打开 AI 助手" style="--ai-orb-x:${position.x}px;--ai-orb-y:${position.y}px">${geminiMark()}</button>
      <button class="ai-orb-restore" type="button" data-ai-orb-restore aria-label="显示 AI 助手"><span>‹</span></button>
      <button class="ai-drawer-scrim" type="button" data-ai-drawer-close aria-label="关闭 AI 助手"></button>
      <aside class="ai-copilot-drawer" aria-label="AI 助手" aria-hidden="${state.drawerOpen ? 'false' : 'true'}">
        <div class="ai-drawer-wallpaper" aria-hidden="true"><img data-ai-drawer-wallpaper-image alt=""></div>
        <div class="ai-drawer-material" aria-hidden="true"></div>
        <header class="ai-copilot-header">
          <div class="ai-copilot-header-left">
            <button class="ai-copilot-icon-button ${state.tab === 'history' ? 'is-active' : ''}" type="button" data-ai-history-toggle title="历史对话" aria-label="历史对话">${historyIcon()}</button>
            <div class="ai-copilot-title"><strong>${state.tab === 'history' ? '历史对话' : escapeHtml(conversationTitle())}</strong></div>
          </div>
          <div class="ai-copilot-header-right">
            ${state.tab === 'history' ? `<button class="ai-copilot-icon-button" type="button" data-ai-history-exit title="退出历史" aria-label="退出历史">${icon('back')}</button>` : ''}
            ${connectionBadge()}
            <button class="ai-copilot-icon-button" type="button" data-ai-drawer-close title="关闭" aria-label="关闭 AI 助手">${icon('close')}</button>
          </div>
        </header>
        <div class="ai-copilot-body">${state.tab === 'history' ? historyView() : chatView()}</div>
      </aside>
    </div>`;
  }

  function orbPosition() {
    const size = 58;
    const margin = 22;
    const maxX = Math.max(margin, window.innerWidth - size - margin);
    const maxY = Math.max(margin, window.innerHeight - size - margin);
    return {
      x: Math.max(margin, Math.min(maxX, state.orb.x === null ? maxX : state.orb.x)),
      y: Math.max(margin, Math.min(maxY, state.orb.y === null ? maxY : state.orb.y))
    };
  }

  function saveOrbState() {
    try { localStorage.setItem('dreamingwrt.ai.orb', JSON.stringify(state.orb)); } catch (_) {}
  }

  function geminiMark() {
    return `<svg viewBox="0 0 296 298" fill="none" aria-hidden="true"><mask id="dwrt-ai-gemini-mask" width="296" height="298" x="0" y="0" maskUnits="userSpaceOnUse" style="mask-type:alpha"><path fill="#3186FF" d="M141.201 4.886c2.282-6.17 11.042-6.071 13.184.148l5.985 17.37a184.004 184.004 0 0 0 111.257 113.049l19.304 6.997c6.143 2.227 6.156 10.91.02 13.155l-19.35 7.082a184.001 184.001 0 0 0-109.495 109.385l-7.573 20.629c-2.241 6.105-10.869 6.121-13.133.025l-7.908-21.296a184 184 0 0 0-109.02-108.658l-19.698-7.239c-6.102-2.243-6.118-10.867-.025-13.132l20.083-7.467A183.998 183.998 0 0 0 133.291 26.28l7.91-21.394Z"/></mask><g mask="url(#dwrt-ai-gemini-mask)"><g filter="url(#dwrt-ai-gemini-blue)"><ellipse cx="163" cy="149" fill="#3689FF" rx="196" ry="159"/></g><g filter="url(#dwrt-ai-gemini-yellow-a)"><ellipse cx="33.5" cy="142.5" fill="#F6C013" rx="68.5" ry="72.5"/></g><g filter="url(#dwrt-ai-gemini-yellow-b)"><ellipse cx="19.5" cy="148.5" fill="#F6C013" rx="68.5" ry="72.5"/></g><g filter="url(#dwrt-ai-gemini-red-a)"><path fill="#FA4340" d="M194 10.5C172 82.5 65.5 134.333 22.5 135L144-66l50 76.5Z"/></g><g filter="url(#dwrt-ai-gemini-red-b)"><path fill="#FA4340" d="M190.5-12.5C168.5 59.5 62 111.333 19 112L140.5-89l50 76.5Z"/></g><g filter="url(#dwrt-ai-gemini-green-a)"><path fill="#14BB69" d="M194.5 279.5C172.5 207.5 66 155.667 23 155l121.5 201 50-76.5Z"/></g><g filter="url(#dwrt-ai-gemini-green-b)"><path fill="#14BB69" d="M196.5 320.5C174.5 248.5 68 196.667 25 196l121.5 201 50-76.5Z"/></g></g><defs><filter id="dwrt-ai-gemini-blue" width="464" height="390" x="-69" y="-46" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur result="effect1_foregroundBlur" stdDeviation="18"/></filter><filter id="dwrt-ai-gemini-yellow-a" width="265" height="273" x="-99" y="6" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur result="effect1_foregroundBlur" stdDeviation="32"/></filter><filter id="dwrt-ai-gemini-yellow-b" width="265" height="273" x="-113" y="12" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur result="effect1_foregroundBlur" stdDeviation="32"/></filter><filter id="dwrt-ai-gemini-red-a" width="299.5" height="329" x="-41.5" y="-130" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur result="effect1_foregroundBlur" stdDeviation="32"/></filter><filter id="dwrt-ai-gemini-red-b" width="299.5" height="329" x="-45" y="-153" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur result="effect1_foregroundBlur" stdDeviation="32"/></filter><filter id="dwrt-ai-gemini-green-a" width="299.5" height="329" x="-41" y="91" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur result="effect1_foregroundBlur" stdDeviation="32"/></filter><filter id="dwrt-ai-gemini-green-b" width="299.5" height="329" x="-39" y="132" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur result="effect1_foregroundBlur" stdDeviation="32"/></filter></defs></svg>`;
  }

  function historyIcon() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/></svg>';
  }

  function chatView() {
    const configured = credentialReady();
    const messages = state.current.messages;
    return `
      <section class="ai-chat-card ai-page-card ${isGlobal ? 'ai-drawer-chat' : 'dwrt-kit-page-surface dwrt-kit-glass-surface'}">
        <div class="ai-chat-scroll" data-ai-scroll="chat" role="log" aria-live="polite">
          ${state.loading ? loadingState('正在读取 AI 配置') : messages.length ? messages.map(messageMarkup).join('') : chatEmptyState()}
          ${state.loading ? '' : toolActivityMarkup()}
          ${state.loading ? '' : authorizationMarkup()}
        </div>
        <footer class="ai-composer-wrap">
          ${state.chatError ? `<div class="ai-inline-message error">${icon('alert')}<span>${escapeHtml(state.chatError)}</span></div>` : ''}
          ${state.notice ? `<div class="ai-inline-message success">${icon('check')}<span>${escapeHtml(state.notice)}</span></div>` : ''}
          ${attachmentTray()}
          <div class="ai-composer ${configured ? '' : 'is-disabled'}">
            <input type="file" data-ai-file hidden multiple accept=".txt,.log,.conf,.json,.yaml,.yml,.md,text/*,application/json">
            <textarea data-ai-prompt rows="1" maxlength="12000" aria-label="AI 消息" placeholder="${configured ? '输入消息，/new 开始新对话' : 'AI 当前未配置'}" ${configured && !state.sending ? '' : 'disabled'}>${escapeHtml(state.prompt)}</textarea>
            <div class="ai-composer-bar">
              <div class="ai-composer-tools">
                ${addMenu(configured)}
              </div>
              <div class="ai-composer-options">
                ${runtimeMenu()}
                ${state.stream.active && (state.config.capabilities.response_cancel || state.stream.controller)
                  ? `<button class="ai-send-button is-stop" type="button" data-ai-stop title="停止生成" aria-label="停止生成" ${state.stream.cancelling ? 'disabled' : ''}>${state.stream.cancelling ? icon('loader') : icon('stop')}</button>`
                  : `<button class="ai-send-button" type="button" data-ai-send title="发送" aria-label="发送" ${configured && !state.sending ? '' : 'disabled'}>${state.sending ? icon('loader') : icon('send')}</button>`}
              </div>
            </div>
          </div>
        </footer>
      </section>
    `;
  }

  function chatEmptyState() {
    return '<div class="ai-chat-empty" aria-hidden="true"></div>';
  }

  function addMenu(configured) {
    const disabled = !configured || state.sending;
    return `<div class="ai-add-control ${state.addMenuOpen ? 'is-open' : ''}">
      <button class="ai-composer-icon" type="button" data-ai-add-toggle title="添加" aria-label="添加内容" aria-haspopup="menu" aria-expanded="${state.addMenuOpen ? 'true' : 'false'}" ${disabled ? 'disabled' : ''}>${icon('plus')}</button>
      ${state.addMenuOpen ? `<div class="ai-add-popover" role="menu">
        <button type="button" role="menuitem" data-ai-add-file>${icon('paperclip')}<span><strong>上传附件</strong><small>日志、配置或文本文件</small></span></button>
        ${isGlobal ? `<button type="button" role="menuitem" data-ai-add-page>${icon('page-add')}<span><strong>添加当前页面</strong><small>发送当前页面内容</small></span></button>` : ''}
      </div>` : ''}
    </div>`;
  }

  function runtimeMenu() {
    const effort = REASONING_LABELS[currentEffort()] || currentEffort();
    return `<div class="ai-runtime-control ${state.runtimeMenuOpen ? 'is-open' : ''}">
      <button class="ai-runtime-trigger" type="button" data-ai-runtime-toggle aria-haspopup="menu" aria-expanded="${state.runtimeMenuOpen ? 'true' : 'false'}" ${state.loading ? 'disabled' : ''}>
        <span>${escapeHtml(currentModel())}</span><small>${escapeHtml(effort)}</small>${icon('chevron-down')}
      </button>
      ${state.runtimeMenuOpen ? runtimePopover() : ''}
    </div>`;
  }

  function runtimePopover() {
    if (state.runtimePane === 'model') {
      const models = uniqueModels([currentModel(), ...state.models]);
      return `<div class="ai-runtime-popover ai-runtime-choice-list" role="menu">
        <button class="ai-runtime-back" type="button" data-ai-runtime-pane="main">${icon('back')}<strong>模型</strong></button>
        <div class="ai-runtime-list">${models.map((model) => `<button type="button" role="menuitemradio" aria-checked="${model === currentModel() ? 'true' : 'false'}" data-ai-model-option="${escapeHtml(model)}"><span>${escapeHtml(model)}</span>${model === currentModel() ? icon('check') : ''}</button>`).join('')}</div>
      </div>`;
    }
    if (state.runtimePane === 'effort') {
      const provided = state.config.capabilities.reasoning_effort_values;
      const values = uniqueModels([currentEffort(), ...(provided.length ? provided : ['auto', 'none', 'minimal', 'low', 'medium', 'high', 'xhigh'])]);
      return `<div class="ai-runtime-popover ai-runtime-choice-list" role="menu">
        <button class="ai-runtime-back" type="button" data-ai-runtime-pane="main">${icon('back')}<strong>推理强度</strong></button>
        <div class="ai-runtime-list">${values.map((value) => `<button type="button" role="menuitemradio" aria-checked="${value === currentEffort() ? 'true' : 'false'}" data-ai-effort-option="${escapeHtml(value)}"><span>${escapeHtml(REASONING_LABELS[value] || value)}</span>${value === currentEffort() ? icon('check') : ''}</button>`).join('')}</div>
      </div>`;
    }
    if (state.runtimePane === 'advanced') {
      return `<div class="ai-runtime-popover ai-runtime-choice-list" role="menu">
        <button class="ai-runtime-back" type="button" data-ai-runtime-pane="main">${icon('back')}<strong>高级</strong></button>
        <div class="ai-runtime-list">${TOOL_POLICIES.map(([value, label]) => `<button type="button" role="menuitemradio" aria-checked="${value === currentToolPolicy() ? 'true' : 'false'}" data-ai-policy-option="${value}"><span>${escapeHtml(label)}</span>${value === currentToolPolicy() ? icon('check') : ''}</button>`).join('')}</div>
      </div>`;
    }
    return `<div class="ai-runtime-popover" role="menu">
      <button type="button" role="menuitem" data-ai-runtime-pane="model"><strong>模型</strong><span>${escapeHtml(currentModel())}</span>${icon('chevron-right')}</button>
      <button type="button" role="menuitem" data-ai-runtime-pane="effort" ${reasoningDisabled() ? 'disabled' : ''}><strong>推理强度</strong><span>${escapeHtml(REASONING_LABELS[currentEffort()] || currentEffort())}</span>${icon('chevron-right')}</button>
      <div class="ai-runtime-divider"></div>
      <button type="button" role="menuitem" data-ai-runtime-pane="advanced"><strong>高级</strong>${icon('chevron-right')}</button>
    </div>`;
  }

  function messageMarkup(message) {
    const attachments = asArray(message.attachments);
    return `
      <article class="ai-message ${message.role === 'user' ? 'is-user' : 'is-assistant'} ${message.streaming ? 'is-streaming' : ''}">
        <div class="ai-message-author">${message.role === 'user' ? '你' : 'AI'}</div>
        <div class="ai-message-bubble">
          <div class="ai-message-content" data-ai-message-body="${escapeHtml(message.id)}">${escapeHtml(message.content).replace(/\n/g, '<br>')}${message.streaming ? '<span class="ai-stream-caret" aria-hidden="true"></span>' : ''}</div>
          ${attachments.length ? `<div class="ai-message-files">${attachments.map((file) => `<span>${icon('file')}${escapeHtml(file.name)}</span>`).join('')}</div>` : ''}
          ${message.streaming ? '' : `<time>${formatMessageTime(message.created_at)}</time>`}
        </div>
      </article>
    `;
  }

  function toolActivityMarkup() {
    if (!state.toolActivity.length) return '';
    return `
      <section class="ai-tool-activity" aria-label="工具调用">
        ${state.toolActivity.map((item) => {
          const status = firstText(item.status, 'completed');
          const label = ({
            running: '执行中',
            pending_authorization: '等待授权',
            authorized: '已授权',
            denied: '已拒绝',
            completed: '已完成',
            execution_failed: '执行失败'
          })[status] || status;
          const tone = status === 'execution_failed' || status === 'denied'
            ? 'danger'
            : status === 'pending_authorization' || status === 'running'
              ? 'warning'
              : 'success';
          return `<div class="ai-tool-chip is-${tone}">
            ${icon('shield')}
            <b>${escapeHtml(toolLabel(item.tool))}</b>
            <small>${escapeHtml(label)}</small>
            ${item.error ? `<em>${escapeHtml(item.error)}</em>` : ''}
          </div>`;
        }).join('')}
      </section>
    `;
  }

  function authorizationMarkup() {
    if (!state.pendingAuthorizations.length) return '';
    return `
      <section class="ai-tool-auth" aria-label="工具授权请求">
        ${state.pendingAuthorizations.map((item) => {
          const definition = toolDefinition(item.tool);
          const busy = state.authorizing === item.auth_id || state.resuming;
          const parameters = Object.keys(item.parameters || {}).length
            ? JSON.stringify(item.parameters, null, 2)
            : '';
          return `<article class="ai-tool-auth-card">
            <header>
              <strong>${escapeHtml(toolLabel(item.tool))}</strong>
              ${ui.statusBadgeMarkup?.(riskLabel(item.risk_level), riskTone(item.risk_level)) || `<span>${escapeHtml(riskLabel(item.risk_level))}</span>`}
            </header>
            <p>${escapeHtml(firstText(definition?.description, '模型请求执行该工具，请确认后继续。'))}</p>
            ${parameters ? `<pre class="ai-tool-auth-params">${escapeHtml(parameters)}</pre>` : ''}
            ${item.required_role ? `<small>需要角色：${escapeHtml(item.required_role)}</small>` : ''}
            <footer>
              <button class="ai-secondary-button" type="button" data-ai-tool-deny="${item.auth_id}" ${busy ? 'disabled' : ''}>${icon('close')}拒绝</button>
              <button class="ai-primary-button" type="button" data-ai-tool-approve="${item.auth_id}" ${busy ? 'disabled' : ''}>${busy ? icon('loader') : icon('check')}允许执行</button>
            </footer>
          </article>`;
        }).join('')}
      </section>
    `;
  }

  function attachmentTray() {
    if (!state.attachments.length) return '';
    return `
      <div class="ai-attachment-tray" aria-label="待发送附件">
        ${state.attachments.map((file, index) => `
          <span class="ai-attachment-chip">
            ${icon('file')}<b>${escapeHtml(file.name)}</b><small>${formatFileSize(file.size)}</small>
            <button type="button" data-ai-remove-file="${index}" title="移除附件" aria-label="移除 ${escapeHtml(file.name)}">${icon('close')}</button>
          </span>
        `).join('')}
      </div>
    `;
  }

  function historyView() {
    const rows = filteredHistory();
    if (isGlobal) {
      const totalPages = Math.max(1, Math.ceil(rows.length / state.historyPageSize));
      const page = Math.max(1, Math.min(totalPages, state.historyPage));
      const pageRows = rows.slice((page - 1) * state.historyPageSize, page * state.historyPageSize);
      return `<section class="ai-drawer-history">
        <div class="ai-drawer-history-toolbar"><label>${icon('search')}<input type="search" value="${escapeHtml(state.historyQuery)}" placeholder="搜索对话" data-ai-history-search></label></div>
        <div class="ai-drawer-history-list" data-ai-scroll="history">${state.historyLoading ? loadingState('正在读取历史对话') : pageRows.length ? pageRows.map(historyStrip).join('') : `<div class="ai-empty-state"><strong>${state.historyQuery ? '没有匹配的对话' : '暂无历史对话'}</strong></div>`}</div>
        <footer class="ai-history-pagination"><button type="button" data-ai-history-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>上一页</button><span>${page} / ${totalPages}</span><button type="button" data-ai-history-page="${page + 1}" ${page >= totalPages ? 'disabled' : ''}>下一页</button></footer>
      </section>`;
    }
    return `
      <section class="ai-history-card ai-page-card dwrt-kit-page-surface dwrt-kit-table-wrap dwrt-kit-ikuai-table-wrap dwrt-kit-glass-surface">
        <div class="dwrt-kit-table-toolbar ai-history-toolbar">
          <div class="dwrt-kit-table-title">
            <strong>历史对话</strong>
            <span>${state.historyLoading ? '正在读取' : state.historyError ? escapeHtml(state.historyError) : '按最近更新时间排序'}</span>
          </div>
          <div class="ai-history-actions">
            <label class="ai-history-search" data-dwrt-component="expand-search">${icon('search')}<input type="search" value="${escapeHtml(state.historyQuery)}" placeholder="搜索对话" data-ai-history-search></label>
            <span class="dwrt-kit-table-count">${formatInteger(rows.length)} 条</span>
            <button class="ai-secondary-button" type="button" data-ai-new>新建对话</button>
          </div>
        </div>
        <div class="dwrt-kit-table-scroll ai-history-scroll" data-ai-scroll="history">
          <table class="dwrt-kit-table dwrt-kit-ikuai-table ai-history-table">
            <thead><tr><th>对话</th><th>消息</th><th>模型</th><th>用量</th><th>更新时间</th><th class="ai-actions-column">操作</th></tr></thead>
            <tbody>
              ${state.historyLoading ? `<tr><td colspan="6" class="dwrt-kit-table-empty">正在读取历史对话</td></tr>` : rows.length ? rows.map(historyRow).join('') : `<tr><td colspan="6" class="dwrt-kit-table-empty">${state.historyQuery ? '没有匹配的对话' : '暂无历史对话'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function historyStrip(item) {
    const deleting = state.deletingConversation === item.id;
    return `<article class="ai-history-strip ${state.loadingConversation === item.id ? 'is-loading' : ''}"><button type="button" data-ai-open-history="${escapeHtml(item.id)}"><strong>${escapeHtml(item.title)}</strong><span>${formatHistoryDate(item.updated_at)}</span><small>${escapeHtml(item.model || '--')} · ${formatInteger(item.message_count)} 条消息</small></button><button class="ai-history-strip-delete" type="button" data-ai-delete-history="${escapeHtml(item.id)}" title="删除对话" aria-label="删除 ${escapeHtml(item.title)}" ${deleting ? 'disabled' : ''}>${deleting ? icon('loader') : icon('trash')}</button></article>`;
  }

  function historyRow(item) {
    const totalTokens = firstNumber(item.usage?.total_tokens);
    const deleting = state.deletingConversation === item.id;
    return `
      <tr class="ai-history-row ${state.loadingConversation === item.id ? 'is-loading' : ''}" data-ai-open-history="${escapeHtml(item.id)}" tabindex="0">
        <td><strong>${escapeHtml(item.title)}</strong><span class="ai-history-effort">${escapeHtml(REASONING_LABELS[item.reasoning_effort] || item.reasoning_effort || '自动')}</span></td>
        <td class="num">${formatInteger(item.message_count)}</td>
        <td><code>${escapeHtml(item.model || '--')}</code></td>
        <td class="num">${totalTokens ? formatInteger(totalTokens) : '--'}</td>
        <td><time>${formatRelativeTime(item.updated_at)}</time></td>
        <td class="ai-actions-column"><button class="ai-row-action danger" type="button" data-ai-delete-history="${escapeHtml(item.id)}" title="删除对话" aria-label="删除 ${escapeHtml(item.title)}" ${deleting ? 'disabled' : ''}>${deleting ? icon('loader') : icon('trash')}</button></td>
      </tr>
    `;
  }

  function filteredHistory() {
    const query = state.historyQuery.trim().toLowerCase();
    if (!query) return state.history;
    return state.history.filter((item) => `${item.title} ${item.model} ${item.reasoning_effort}`.toLowerCase().includes(query));
  }

  function formatHistoryDate(value) {
    const timestamp = normalizeTimestamp(value);
    if (!timestamp) return '--';
    return new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(timestamp);
  }

  function oauthStatusText(status = oauthStatus()) {
    if (state.oauth.statusLoading === state.config.provider) return ['checking', '正在检查连接'];
    if (!status) return ['off', '尚未检查'];
    if (status.connected && status.expired) return ['warning', '凭据已过期'];
    if (status.connected) return ['configured', 'OAuth 已连接'];
    if (status.pending) return ['checking', '等待完成授权'];
    return ['off', '尚未连接'];
  }

  function oauthExpiryText(status = oauthStatus()) {
    const expiresAt = firstNumber(status?.expires_at, status?.pending_expires_at);
    if (!expiresAt) return '';
    return new Intl.DateTimeFormat('zh-CN', {
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'
    }).format(expiresAt * (expiresAt < 100000000000 ? 1000 : 1));
  }

  function oauthInput(provider, key, label, options = {}) {
    const value = firstText(state.oauth.inputs[provider]?.[key]);
    return `<label class="ai-field ${options.wide ? 'ai-field-wide' : ''}"><span>${escapeHtml(label)}</span><input type="${options.type || 'text'}" value="${escapeHtml(value)}" placeholder="${escapeHtml(options.placeholder || '')}" autocomplete="off" data-ai-oauth-input="${escapeHtml(key)}" data-ai-oauth-provider="${escapeHtml(provider)}">${options.help ? `<small>${escapeHtml(options.help)}</small>` : ''}</label>`;
  }

  function oauthFlowMarkup(provider) {
    const flow = state.oauth.flow;
    if (!flow || flow.provider !== provider) return '';
    if (provider === 'kimi') {
      const verificationUrl = safeHttpUrl(firstText(flow.verification_uri_complete, flow.verification_uri));
      return `<div class="ai-oauth-device-flow">
        <div><span>设备验证码</span><strong>${escapeHtml(firstText(flow.user_code, '--'))}</strong><small>验证码由 Kimi 生成，页面将按 ${Math.max(1, firstNumber(flow.poll_after_seconds, flow.interval, 5))} 秒间隔检查授权结果。</small></div>
        <div class="ai-oauth-flow-actions"><button class="ai-secondary-button" type="button" data-ai-oauth-copy="${escapeHtml(firstText(flow.user_code))}">${icon('copy')}复制验证码</button>${verificationUrl ? `<a class="ai-primary-button" href="${escapeHtml(verificationUrl)}" target="_blank" rel="noopener noreferrer">${icon('external')}打开授权页面</a>` : ''}</div>
      </div>`;
    }
    if (provider === 'gemini') {
      return `<div class="ai-oauth-flow-note">${icon('external')}<span>Google 授权页面已打开。完成授权后，Dreaming OS 会校验回调中的 state 并由后端交换凭据。</span></div>`;
    }
    return '';
  }

  function oauthPanel() {
    const provider = state.config.provider;
    const capability = oauthProvider(provider);
    const status = oauthStatus(provider);
    const [tone, statusText] = oauthStatusText(status);
    const working = state.oauth.action.startsWith(`${provider}:`);
    if (!state.oauth.available) {
      return `<div class="ai-oauth-unavailable">${icon('alert')}<div><strong>OAuth 接口不可用</strong><span>当前 webd 没有返回 ai-oauth.v1 能力，请继续使用 API Key。</span></div></div>`;
    }
    if (!capability || capability.supported !== true) {
      const reason = oauthReason(capability?.reason, '该提供商当前仅支持 API Key 接入。');
      return `<div class="ai-oauth-unavailable">${icon('key')}<div><strong>${escapeHtml(oauthProviderLabel(provider))} 使用 API Key</strong><span>${escapeHtml(reason)}</span></div></div>`;
    }
    let fields = '';
    let intro = '';
    if (capability.mode === 'authorization_code_pkce_s256') {
      intro = '使用你自己的 Google OAuth 客户端，通过授权码与 PKCE S256 建立连接。';
      fields = `<div class="ai-settings-grid ai-oauth-fields">${oauthInput('gemini', 'client_id', 'Google Client ID', { wide: true, placeholder: 'xxxx.apps.googleusercontent.com' })}${oauthInput('gemini', 'project_id', 'Google Cloud Project ID', { placeholder: 'my-gemini-project' })}${oauthInput('gemini', 'redirect_uri', '回调地址', { placeholder: `${window.location.origin}${window.location.pathname}`, help: '必须与 Google OAuth 客户端中登记的回调地址完全一致。' })}</div>`;
    } else if (capability.mode === 'device_oauth') {
      intro = '通过 Kimi Code 官方设备授权连接，不需要在路由器中输入账号密码。';
    } else if (capability.mode === 'enterprise_wif') {
      intro = '通过 Anthropic Workload Identity Federation 交换短期凭据，不是 Claude 用户账号登录。';
      const rootPath = firstText(capability.identity_token_file_root, '/etc/dreamingwrt/credentials/');
      fields = `<div class="ai-settings-grid ai-oauth-fields">${oauthInput('anthropic', 'identity_token_file', '身份令牌文件', { wide: true, placeholder: `${rootPath}identity.jwt`, help: `仅允许 ${rootPath} 下 root:root、0600 的普通文件。` })}${oauthInput('anthropic', 'federation_rule_id', 'Federation Rule ID', { placeholder: 'fdrl_...' })}${oauthInput('anthropic', 'organization_id', 'Organization ID')}${oauthInput('anthropic', 'service_account_id', 'Service Account ID', { placeholder: 'svac_...' })}${oauthInput('anthropic', 'workspace_id', 'Workspace ID（可选）', { placeholder: 'wrkspc_...' })}</div>`;
    }
    const expiry = oauthExpiryText(status);
    const startLabel = status?.connected ? '重新授权' : capability.mode === 'enterprise_wif' ? '连接 WIF' : '开始授权';
    return `<div class="ai-oauth-card">
      <div class="ai-oauth-card-head"><div><strong>${escapeHtml(oauthProviderLabel(provider))}</strong><span>${escapeHtml(intro)}</span></div>${ui.statusBadgeMarkup?.(statusText, tone === 'configured' ? 'success' : tone === 'checking' ? 'info' : tone === 'warning' ? 'warning' : 'muted') || ''}</div>
      ${status?.state_reason ? `<div class="ai-oauth-inline-error">${escapeHtml(oauthReason(status.state_reason))}</div>` : ''}
      ${fields}
      ${oauthFlowMarkup(provider)}
      <div class="ai-oauth-card-footer"><span>${expiry ? `${status?.pending && !status?.connected ? '授权流程' : '当前凭据'}有效至 ${escapeHtml(expiry)}` : status?.pending ? '存在未完成的授权流程，可以重新开始。' : '访问凭据只保存在路由器的加密存储中。'}</span><div>
        ${status?.connected ? `<button class="ai-secondary-button" type="button" data-ai-oauth-refresh ${working ? 'disabled' : ''}>${state.oauth.action === `${provider}:refresh` ? icon('loader') : icon('refresh')}刷新凭据</button>` : ''}${status?.connected || status?.pending ? `<button class="ai-secondary-button is-danger" type="button" data-ai-oauth-disconnect ${working ? 'disabled' : ''}>${status?.connected ? '断开连接' : '取消授权'}</button>` : ''}
        <button class="ai-primary-button" type="button" data-ai-oauth-start ${working ? 'disabled' : ''}>${state.oauth.action === `${provider}:start` ? icon('loader') : icon('link')}${escapeHtml(startLabel)}</button>
      </div></div>
    </div>`;
  }

  function oauthDisconnectConfirmation() {
    if (!state.oauth.confirmDisconnect) return '';
    const provider = oauthProviderLabel(state.config.provider);
    const markup = window.DWRT_UI_KIT?.confirmationMarkup?.({
      id: 'ai-oauth-disconnect', action: 'ai-oauth-disconnect', tone: 'danger',
      title: `断开 ${provider}`, description: '路由器将删除该提供商的 OAuth 凭据与未完成授权。API Key 不受影响。',
      cancelLabel: '取消', confirmLabel: '断开连接'
    });
    return markup || `<div class="ai-oauth-confirm"><button type="button" data-ai-oauth-disconnect-cancel>取消</button><button type="button" data-ai-oauth-disconnect-confirm>断开连接</button></div>`;
  }

  /*
   * 移除供应商是不可逆写操作，走和 OAuth 断开一致的二次确认
   * （design.md Capability truth 第 7 条：不得削弱写保护）。
   */
  function providerRemoveConfirmation() {
    if (!state.providerRemoveId) return '';
    const item = providerById(state.providerRemoveId);
    if (!item) return '';
    const label = firstText(item.display_name, oauthProviderLabel(item.provider));
    const markup = window.DWRT_UI_KIT?.confirmationMarkup?.({
      id: 'ai-provider-remove', action: 'ai-provider-remove', tone: 'danger',
      title: `移除 ${label}`, description: '路由器将删除该供应商的凭据与已缓存模型列表。全局默认参数与其他供应商不受影响。',
      cancelLabel: '取消', confirmLabel: '移除供应商'
    });
    return markup || `<div class="ai-oauth-confirm"><button type="button" data-ai-provider-remove-cancel>取消</button><button type="button" data-ai-provider-remove-confirm>移除供应商</button></div>`;
  }

  function settingsView() {
    const provider = providerDefinition();
    const apiBaseHelp = state.config.auth_mode === 'oauth'
      ? '留空时后端使用该 OAuth 提供商的官方模型 API 地址'
      : state.config.provider === 'openai_compatible'
        ? 'OpenAI 兼容服务需要填写完整 API Base URL'
        : '留空时后端使用该提供商的默认 API 地址';
    const tab = settingsTab();
    /*
     * 「启用 LLM 服务」总开关只放在高级设置页。
     *
     * 用户 2026-08-04：「启用 llm 服务不用在每一页都显示，在高级设置页面显示就够了」。
     * 它是个全局开关，跟着每个 Tab 复现一遍只是重复占位 —— 概览页已经用「接入状态」
     * 那张卡说明了同一件事，供应商页关心的是选哪家和填凭据，都不需要再放一次开关。
     */
    // 概览的四张卡提到主卡片外面，和其他页面一致；主卡片顶部不再复述 Tab 名。
    return `
      ${tab === 'overview' ? settingsOverviewCards() : ''}
      ${tab === 'advanced' ? settingsMasterCard() : ''}
      <form class="ai-settings-card ai-page-card dwrt-kit-page-surface dwrt-kit-glass-surface" data-ai-scroll="settings">
        ${state.settingsError ? `<div class="ai-inline-message error">${icon('alert')}<span>${escapeHtml(state.settingsError)}</span></div>` : ''}
        ${settingsTabContent(provider, apiBaseHelp)}
        ${settingsFooter()}
      </form>${oauthDisconnectConfirmation()}${providerRemoveConfirmation()}
    `;
  }

  function settingsSavebarMarkup() {
    const dirtyResources = Number(configDirty()) + Number(dispatchDirty());
    return ui.floatingSavebarMarkup?.({
      visible: dirtyResources > 0 || state.saving,
      message: state.saving ? '正在保存 AI 设置…' : `${dirtyResources} 项 AI 配置待保存`,
      busy: state.saving,
      disabled: !dirtyResources,
      discardLabel: '撤销更改',
      saveLabel: '保存并应用'
    }) || '';
  }

  /* 总开关卡片。demo 把「启用 LLM 服务」做成一张独立主控卡，开关在右侧；
     关闭时下方配置主体折叠成一条占位说明，避免摆一屏点了没意义的字段。 */
  function settingsMasterCard() {
    const on = state.config.enabled;
    const ready = credentialReady();
    const badge = state.loading ? '读取中' : on ? (ready ? '运行中' : '缺少凭据') : '未启用';
    const badgeTone = state.loading ? 'neutral' : on ? (ready ? 'ok' : 'warn') : 'neutral';
    return `<section class="ai-master-card ${on ? 'is-active' : ''} dwrt-kit-glass-surface" data-dwrt-component="surface" data-dwrt-surface="stable-glass">
      <div class="ai-master-copy">
        <strong>启用 LLM 服务<span class="ai-master-badge is-${badgeTone}">${escapeHtml(badge)}</span></strong>
        <small>路由器统一管理模型接入凭据，供本机诊断、日志解读与自然语言操作使用。</small>
      </div>
      <label class="ai-switch dwrt-kit-switch" data-dwrt-component="switch" data-dwrt-tooltip="启用 AI">
        <input type="checkbox" data-ai-config="enabled" ${on ? 'checked' : ''} aria-label="启用 LLM 服务">
      </label>
    </section>`;
  }

  // 只保留 id 与标签。Tab 已经说明了当前位置，卡片顶部不再复述描述文案。
  const SETTINGS_TABS = [
    ['overview', '概览'],
    ['provider', '供应商设置'],
    ['advanced', '高级设置']
  ];

  function settingsTab() {
    return SETTINGS_TABS.some(([id]) => id === state.settingsTab) ? state.settingsTab : 'overview';
  }

  function settingsTabsMarkup() {
    const active = settingsTab();
    return `<nav class="dwrt-kit-tabs dwrt-kit-page-tabs ai-primary-tabs ai-settings-tabs" data-dwrt-component="tabs" role="tablist" aria-label="LLM 接入设置视图"><span class="dwrt-kit-tab-pill" aria-hidden="true"></span>${SETTINGS_TABS.map(([id, label]) => `<button class="dwrt-kit-tab ${active === id ? 'is-active' : ''}" type="button" role="tab" data-ai-settings-tab="${id}" data-value="${id}" aria-selected="${active === id ? 'true' : 'false'}">${escapeHtml(label)}</button>`).join('')}</nav>`;
  }

  function settingsTabContent(provider, apiBaseHelp) {
    const tab = settingsTab();
    if (tab === 'overview') return settingsOverviewSection();
    if (tab === 'advanced') return settingsAdvancedSection(provider, apiBaseHelp);
    return settingsProviderSection(provider, apiBaseHelp);
  }

  function settingsOverviewCards() {
    const statusText = connectionSummaryText();
    const authLabel = state.config.auth_mode === 'oauth' ? 'OAuth' : 'API Key';
    const credentialText = state.config.auth_mode === 'oauth'
      ? (oauthStatus()?.connected ? '已连接' : oauthStatus()?.pending ? '授权未完成' : '未连接')
      : state.config.api_key_set ? '已保存' : '未配置';
    const items = [
      { key: 'status', label: '接入状态', value: statusText, detail: state.config.enabled ? '路由器已启用 AI 能力' : 'AI 能力当前关闭', tone: state.config.enabled && credentialReady() ? 'ok' : state.config.enabled ? 'warn' : 'neutral', icon: icon('shield') },
      { key: 'provider', label: '模型提供商', value: oauthProviderLabel(state.config.provider), detail: `认证方式 ${authLabel} · 凭据${credentialText}`, tone: 'info', icon: icon('link') },
      { key: 'model', label: '默认模型', value: firstText(state.config.model, '--'), detail: `最大输出 ${state.config.max_tokens} token`, tone: 'neutral', icon: icon('file') },
      { key: 'runtime', label: '生成参数', value: `温度 ${Number(state.config.temperature).toFixed(1)}`, detail: `思考强度 ${REASONING_LABELS[state.config.reasoning_effort] || state.config.reasoning_effort || 'auto'} · ${toolPolicyLabel(state.config.tool_policy)}`, tone: 'neutral', icon: icon('key') }
    ];
    const cards = typeof ui.overviewCardsMarkup === 'function'
      ? ui.overviewCardsMarkup(items, { label: 'LLM 接入概览', className: 'ai-settings-summary' })
      : `<section class="dwrt-kit-overview-grid ai-settings-summary" aria-label="LLM 接入概览">${items.map((item) => `<article class="dwrt-kit-overview-card is-${item.tone}"><div class="dwrt-kit-overview-content"><span class="dwrt-kit-overview-label">${escapeHtml(item.label)}</span><strong>${escapeHtml(item.value)}</strong><small>${escapeHtml(item.detail)}</small></div><span class="dwrt-kit-overview-icon">${item.icon}</span></article>`).join('')}</section>`;
    return cards;
  }

  /* 概览页主体。事实清单与说明段按用户要求删除（Tab 已说明当前位置，
     四张卡已给出同样的值），这里只保留 provider 侧真正额外的运行态信息。 */
  function settingsOverviewSection() {
    const provider = oauthProviderLabel(state.config.provider);
    const models = state.modelsListed ? state.models.length : 0;
    const rows = [
      ['当前供应商', provider, state.config.auth_mode === 'oauth' ? 'OAuth 授权' : (state.config.api_key_set ? 'API Key 已保存' : 'API Key 未配置')],
      ['可用模型', models ? `${models} 个` : '未同步', models ? '来自最近一次模型列表同步' : '在下方操作栏同步模型列表'],
      ['接口形态', firstText(state.config.reasoning_api_shape, '--'), reasoningDisabled() ? '当前模型不支持 reasoning_effort' : `思考强度 ${REASONING_LABELS[state.config.reasoning_effort] || 'auto'}`]
    ];
    return `<div class="ai-settings-section ai-settings-overview">
      <div class="ai-overview-rows">${rows.map(([label, value, detail]) => `<article><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(detail)}</small></article>`).join('')}</div>
    </div>`;
  }

  function toolPolicyLabel(value) {
    return TOOL_POLICIES.find(([id]) => id === value)?.[1] || String(value || '--');
  }

  function connectionSummaryText() {
    if (state.loading) return '读取中';
    if (!state.config.enabled) return '未启用';
    if (credentialReady()) return '就绪';
    return state.config.auth_mode === 'oauth' ? 'OAuth 未连接' : '缺少 API Key';
  }

  /*
   * 供应商设置。排版参照 demo 1 的两个「舱位」：上面选品牌 + 填凭据，下面是当前生效的
   * 供应商卡（联通状态 / 预载模型 / 针对该供应商的动作）。
   *
   * 2026-08-04 起后端已交付多供应商，30.1 用只读凭据实测：
   *   GET /api/v1/ai/providers        -> 200，capabilities.multi_provider = true
   *   GET /api/v1/ai/dispatch-policy  -> 200，available_strategies 三档
   * 因此 demo 1 的两段结构补齐：顶部全局调度策略条 + 底部「已配置的供应商」列表。
   * 早先这里写的「接口尚未开放」是后端交付之后没同步的过期文案，已删除 ——
   * 页面不得在能力位为真时告诉用户功能不存在（design.md Capability truth 第 6 条）。
   *
   * 能力位为假或端点读取失败时，走的是「未确认 / 未实现」的分类文案，
   * 而不是把列表画成空的假控件。
   */
  function settingsProviderSection(provider, apiBaseHelp) {
    // 「模型提供商 / MODEL PROVIDER」这类小标题复述了 Tab 名与控件语义，按用户要求删除。
    return `${dispatchStrategySection()}
        <div class="ai-settings-section">
          <div class="ai-provider-grid" role="radiogroup" aria-label="模型提供商">
            ${PROVIDERS.map((item) => `
              <button class="ai-provider-button ${state.config.provider === item.id ? 'is-active' : ''}" type="button" role="radio" aria-checked="${state.config.provider === item.id ? 'true' : 'false'}" data-ai-provider="${item.id}">
                ${providerLogoMarkup(item)}
                <strong>${escapeHtml(item.label)}</strong>
                <small class="ai-provider-hint">${escapeHtml(item.hint || '')}</small>
                ${state.config.provider === item.id ? icon('check') : ''}
              </button>
            `).join('')}
          </div>
        </div>
        <div class="ai-settings-section">
          <div class="ai-auth-mode" role="radiogroup" aria-label="认证方式">
            <button type="button" role="radio" aria-checked="${state.config.auth_mode === 'api_key'}" class="${state.config.auth_mode === 'api_key' ? 'is-active' : ''}" data-ai-auth-mode="api_key">${icon('key')}<span><strong>API Key</strong><small>使用提供商密钥</small></span></button>
            <button type="button" role="radio" aria-checked="${state.config.auth_mode === 'oauth'}" class="${state.config.auth_mode === 'oauth' ? 'is-active' : ''}" data-ai-auth-mode="oauth" ${state.oauth.available && oauthProvider()?.supported === true ? '' : 'disabled'}>${icon('link')}<span><strong>OAuth</strong><small>授权连接或企业身份</small></span></button>
          </div>
          ${state.oauth.available && oauthProvider() && oauthProvider()?.supported !== true ? `<div class="ai-auth-mode-hint">${icon('key')}<span>${escapeHtml(oauthReason(oauthProvider()?.reason, '当前提供商仅支持 API Key 接入。'))}</span></div>` : ''}
          ${state.config.auth_mode === 'oauth' ? oauthPanel() : `<div class="ai-settings-grid"><label class="ai-field ai-field-wide"><span>API Key</span><input type="password" autocomplete="new-password" value="${escapeHtml(state.config.api_key_input)}" placeholder="${state.config.api_key_set ? `已保存 ${state.config.api_key_hint || ''}，留空不修改` : '输入 API Key'}" data-ai-config="api_key_input"><small>${state.config.clear_api_key ? '保存后将清除已保存密钥' : state.config.api_key_set ? '密钥已保存，页面不会回显完整内容' : '密钥仅提交到路由器配置接口'}</small></label>${state.config.api_key_set ? `<button class="ai-secondary-button ai-clear-key-button" type="button" data-ai-clear-key>${state.config.clear_api_key ? '撤销清除密钥' : '清除已保存密钥'}</button>` : ''}</div>`}
          ${apiBaseField(provider, apiBaseHelp)}
          ${multiProviderUsable() ? `<div class="ai-provider-draft-actions">
            <button class="ai-secondary-button" type="button" data-ai-provider-add ${state.providerBusy.action === 'add' ? 'disabled' : ''}>${state.providerBusy.action === 'add' ? icon('loader') : icon('check')}添加到已配置列表</button>
          </div>` : ''}
        </div>
        ${settingsProviderList()}`;
  }

  /*
   * API Base URL。**和凭据放在同一页**：用户 2026-08-09 明确指出
   * 「openai 兼容的 API key，设置它主要是方便用户用中转站，结果你只让我填写 key
   * 没让我填写上游 URL……把 api 地址放到了高级设置里？拿过来，为什么要换个页面
   * 才能配完这个东西？」——中转站的 key 与端点是一组凭据，分到两个 Tab 意味着
   * 配一个供应商要来回切页，是错的。高级设置页不再重复渲染这个字段。
   *
   * 标题按用户要求保留英文原名 `API Base URL`，不译成「API 基础地址」。
   */
  function apiBaseField(provider, apiBaseHelp) {
    const compat = state.config.provider === 'openai_compatible';
    return `<label class="ai-field ai-field-wide ai-api-base-field"><span>API Base URL${compat ? '<em class="ai-field-tag">必填</em>' : ''}</span>`
      + `<input type="url" value="${escapeHtml(state.config.api_base)}" placeholder="${escapeHtml(provider?.base || 'https://example.com/v1')}" data-ai-config="api_base">`
      + `<small>${escapeHtml(apiBaseHelp)}</small></label>`;
  }

  /*
   * 供应商磁贴上的品牌图标。图标来自固件自带的 `/static/images/logo/`，
   * 加载失败就隐藏 img 让底下的 `mark` 字形显出来 —— 一个 404 不该在磁贴上
   * 留个破图占位（与 insights-flows 的图标兜底同一口径）。
   */
  function providerLogoMarkup(item) {
    const mark = escapeHtml(item.mark || 'API');
    if (!item.logo) return `<span class="ai-provider-mark is-glyph" aria-hidden="true"><i>${mark}</i></span>`;
    return `<span class="ai-provider-mark" aria-hidden="true">`
      + `<img src="/static/images/logo/${encodeURIComponent(item.logo)}" alt="" loading="lazy" decoding="async"`
      + ` onerror="this.parentElement?.classList.add('is-glyph');this.remove()">`
      + `<i>${mark}</i></span>`;
  }

  const STRATEGY_LABELS = {
    single: ['单供应商', '只用主通道，不自动切换'],
    failover: ['故障切换', '主通道失败时按优先级顺延'],
    load_balance: ['负载均衡', '按权重把请求分散到多个通道']
  };

  function strategyLabel(id) {
    return STRATEGY_LABELS[id]?.[0] || String(id || '--');
  }

  function dispatchStrategies() {
    /*
     * 三档一律来自后端：优先用 `/ai/dispatch-policy` 的 `available_strategies`，
     * 其次用 `/ai/providers` 能力位里的 `dispatch_strategies`。
     * **前端不硬编码 ['single','failover','load_balance']** —— 枚举归后端，
     * 否则后端加减一档时页面会摆出一个点了没用的选项。
     */
    const fromPolicy = state.dispatch.policy?.available_strategies || [];
    if (fromPolicy.length) return fromPolicy;
    return state.config.capabilities.dispatch_strategies || [];
  }

  /*
   * 「能力位为真」与「列表端点真的能用」是两件事：能力位来自 `/ai/config`，
   * 而 `/ai/providers` 可能 404 / 500。此时不能摆出「添加到已配置列表」——
   * 点了必然失败，属于假控件。判据是列表端点自己读成功了（design.md 第 1 条：
   * 资源端点自己才是它可用性的权威）。
   */
  function multiProviderUsable() {
    return state.config.capabilities.multi_provider && state.providers.loaded && !state.providers.error;
  }

  /* demo 1 顶部的全局调度策略条：左侧说明，右侧药丸式切换器。 */
  function dispatchStrategySection() {
    if (!state.config.capabilities.multi_provider) return multiProviderUnavailableNote();
    const policy = state.dispatch.policy;
    const strategies = dispatchStrategies();
    let body = '';
    if (state.dispatch.error) {
      body = `<p class="ai-configured-error">${icon('alert')}<span>${escapeHtml(state.dispatch.error)}</span></p>`;
    } else if (!state.dispatch.loaded || !policy) {
      body = `<p class="ai-configured-note">${escapeHtml(state.dispatch.loading ? '读取调度策略…' : '调度策略尚未确认')}</p>`;
    } else if (!strategies.length) {
      // 枚举拿不到时不自造选项，如实说明。
      body = `<p class="ai-configured-note">当前策略 ${escapeHtml(strategyLabel(policy.strategy))}。后端未返回可选策略集合，暂不提供切换。</p>`;
    } else {
      const active = state.dispatch.draftStrategy || policy.strategy;
      const busy = Boolean(state.saving);
      body = `<div class="ai-strategy-switcher" role="radiogroup" aria-label="全局调度策略">
            ${strategies.map((id) => `
              <button class="ai-strategy-pill ${active === id ? 'is-active' : ''}" type="button" role="radio" aria-checked="${active === id ? 'true' : 'false'}" data-ai-strategy="${escapeHtml(id)}" ${busy ? 'disabled' : ''}>
                <span>${escapeHtml(strategyLabel(id))}</span>
              </button>
            `).join('')}
          </div>`;
    }
    const detail = policy
      ? `${policy.enabled_provider_count} / ${policy.provider_count} 个供应商已启用${policy.strategy === 'failover' ? ` · 最多尝试 ${policy.failover_max_attempts} 次 · 单次 ${Math.round(policy.failover_timeout_ms / 1000)}s 超时` : ''}`
      : '';
    const hint = strategyHint(policy);
    return `<div class="ai-settings-section ai-strategy-section">
          <div class="ai-strategy-bar">
            <div class="ai-strategy-copy">
              <strong>全局调度策略</strong>
              <small>${escapeHtml(detail || '配置多个供应商时，决定请求如何分发')}</small>
            </div>
            ${body}
          </div>
          ${hint ? `<p class="ai-configured-note ai-strategy-hint">${icon('alert')}<span>${escapeHtml(hint)}</span></p>` : ''}
        </div>`;
  }

  /*
   * `single` 缺主供应商时后端返 422 `primary_required`，那是契约不是错误，
   * 页面要把它说成「请先指定主供应商」而不是弹一个失败框。这里提前把同样的
   * 状态渲染成提示，避免用户点了才知道。
   */
  function strategyHint(policy) {
    if (!policy) return '';
    if (!policy.provider_count) return '尚未配置任何供应商，策略保存后不会生效。';
    if (policy.strategy === 'single' && !policy.primary_ready) return '当前为单供应商策略，但没有可用的主供应商，请先把一个供应商设为主通道。';
    if (policy.strategy !== 'single' && policy.enabled_provider_count < 2) return `${strategyLabel(policy.strategy)} 需要至少两个已启用的供应商，当前只有 ${policy.enabled_provider_count} 个。`;
    return '';
  }

  /*
   * 能力位为假、或供应商端点读不到时的说明。**指名道姓写缺哪一个**，
   * 不用一句笼统的「接口尚未开放」覆盖一整批已就绪的能力（design.md 第 3、4 条：
   * 「能力为 false」与「能力未确认」是两种状态，文案必须区分）。
   */
  function multiProviderUnavailableNote() {
    const reason = firstText(state.config.capabilities.multi_provider_reason);
    const detail = state.providers.error
      ? state.providers.error
      : reason === 'not_implemented'
        ? `当前固件未实现多供应商调度（${ENDPOINTS.providers}）。单供应商配置仍然可用。`
        : `后端未声明多供应商能力（capabilities.multi_provider）${reason ? `：${reason}` : ''}。单供应商配置仍然可用。`;
    return `<div class="ai-settings-section"><p class="ai-configured-capability">${icon('key')}<span>${escapeHtml(detail)}</span></p></div>`;
  }

  function providerLastCheckBadge(item) {
    if (!item.enabled) return { tone: 'neutral', text: '未启用' };
    if (!item.api_key_set && item.auth_mode !== 'oauth') return { tone: 'warn', text: '缺少 API Key' };
    const check = item.last_check;
    if (check.state === 'ok') return { tone: 'ok', text: check.latency_ms === null ? '已联通' : `已联通 · ${check.latency_ms} ms` };
    if (check.state === 'fail') return { tone: 'error', text: check.error_kind ? `测试失败 · ${check.error_kind}` : '测试失败' };
    return { tone: 'info', text: item.role === 'primary' ? '主通道 · 未测试' : '备用中 · 未测试' };
  }

  /*
   * demo 1 下半部分的「已配置的供应商」。列表与条数来自 `GET /ai/providers`，
   * 空列表渲染真实空态（design.md 第 5 条：`[]` 是正常业务状态，不是缺接口），
   * **不回退成「只有一个供应商」的旧叙事**。
   */
  function settingsProviderList() {
    if (!state.config.capabilities.multi_provider) return settingsConfiguredProvider();
    if (state.providers.error) {
      return `<div class="ai-settings-section ai-configured-section">
          <h3 class="ai-configured-heading">已配置的供应商</h3>
          <p class="ai-configured-error">${icon('alert')}<span>${escapeHtml(state.providers.error)}</span></p>
        </div>`;
    }
    if (!state.providers.loaded) {
      return `<div class="ai-settings-section ai-configured-section">
          <h3 class="ai-configured-heading">已配置的供应商</h3>
          <p class="ai-configured-note">${escapeHtml(state.providers.loading ? '读取供应商列表…' : '供应商列表尚未确认')}</p>
        </div>`;
    }
    const count = state.providers.count;
    const items = state.providers.items;
    const head = `<h3 class="ai-configured-heading">已配置的供应商<em class="ai-configured-count">${count ? `当前共 ${count} 个` : '暂无'}</em></h3>`;
    if (!items.length) {
      return `<div class="ai-settings-section ai-configured-section">
          ${head}
          <div class="ai-provider-empty">
            ${icon('key')}
            <strong>还没有配置任何供应商</strong>
            <small>在上方选择品牌并填入凭据后，点「添加到已配置列表」即可加入调度。</small>
          </div>
        </div>`;
    }
    return `<div class="ai-settings-section ai-configured-section">
          ${head}
          <div class="ai-provider-list">${items.map(providerRowMarkup).join('')}</div>
        </div>`;
  }

  function providerRowMarkup(item) {
    const definition = providerDefinition(item.provider);
    const badge = providerLastCheckBadge(item);
    const label = firstText(item.display_name, oauthProviderLabel(item.provider));
    const authText = item.auth_mode === 'oauth' ? 'OAuth 授权' : 'API Key 模式';
    const roleText = item.role === 'primary' ? '主通道' : '故障热备';
    const endpoint = firstText(item.api_base, definition.base, '提供商默认端点');
    // model_count 为 0 且没同步过是「未同步」，不是「0 个可用」（契约第三节）。
    const modelText = item.models_synced_at || item.model_count
      ? `${item.model_count} 个可用`
      : '未同步';
    const busy = state.providerBusy.id === item.id ? state.providerBusy.action : '';
    const keyText = item.auth_mode === 'oauth' ? 'OAuth 凭据' : item.api_key_set ? `密钥 ${item.api_key_hint || '已保存'}` : '未保存密钥';
    return `<article class="ai-provider-row" data-ai-provider-id="${escapeHtml(item.id)}">
          <div class="ai-configured-head">
            <span class="ai-configured-mark" aria-hidden="true">${escapeHtml(definition.mark || 'API')}</span>
            <div class="ai-configured-title">
              <strong>${escapeHtml(label)}</strong>
              <small>${escapeHtml(`${authText} · ${roleText} · ${endpoint}`)}</small>
            </div>
            <span class="ai-configured-badge is-${badge.tone}">${escapeHtml(badge.text)}</span>
          </div>
          <div class="ai-configured-models">
            <span>${escapeHtml(`${keyText}${item.default_model ? ` · 默认模型 ${item.default_model}` : ''}`)}</span>
            <b>${escapeHtml(modelText)}</b>
          </div>
          ${item.last_check.state === 'fail' && item.last_check.error ? `<p class="ai-configured-error">${icon('alert')}<span>${escapeHtml(item.last_check.error)}</span></p>` : ''}
          <div class="ai-provider-row-actions">
            <button class="ai-secondary-button" type="button" data-ai-provider-test="${escapeHtml(item.id)}" ${busy ? 'disabled' : ''}>${busy === 'test' ? icon('loader') : icon('link')}测试</button>
            <button class="ai-secondary-button" type="button" data-ai-provider-sync="${escapeHtml(item.id)}" ${busy ? 'disabled' : ''}>${busy === 'sync' ? icon('loader') : icon('refresh')}拉模型</button>
            <button class="ai-secondary-button" type="button" data-ai-provider-primary="${escapeHtml(item.id)}" ${busy || item.role === 'primary' ? 'disabled' : ''}>${busy === 'primary' ? icon('loader') : icon('check')}设为主通道</button>
            <button class="ai-secondary-button ai-danger-button" type="button" data-ai-provider-remove="${escapeHtml(item.id)}" ${busy ? 'disabled' : ''}>${busy === 'remove' ? icon('loader') : icon('alert')}移除</button>
          </div>
        </article>`;
  }

  /* 单供应商回退视图。仅在后端未声明 multi_provider 时使用。 */
  function settingsConfiguredProvider() {
    const provider = providerDefinition();
    const label = oauthProviderLabel(state.config.provider);
    const authText = state.config.auth_mode === 'oauth' ? 'OAuth 授权' : 'API Key 模式';
    const ready = credentialReady();
    const check = state.providerCheck || { state: 'unknown' };
    let badgeTone = 'neutral';
    let badgeText = '未配置凭据';
    if (state.loading) { badgeTone = 'neutral'; badgeText = '读取中'; }
    else if (!ready) { badgeTone = 'warn'; badgeText = state.config.auth_mode === 'oauth' ? 'OAuth 未连接' : '缺少 API Key'; }
    else if (check.state === 'ok') { badgeTone = 'ok'; badgeText = check.latency ? `已联通 · ${check.latency} ms` : '已联通'; }
    else if (check.state === 'fail') { badgeTone = 'error'; badgeText = '测试失败'; }
    else { badgeTone = 'info'; badgeText = '凭据已就绪 · 未测试'; }
    const models = state.modelsListed ? state.models.length : 0;
    // 预载模型只列前三个，避免同步回一长串把卡片撑开。
    const preview = models ? state.models.slice(0, 3).join('、') : '';
    const endpoint = firstText(state.config.api_base, provider.base, '使用提供商默认端点');
    return `<div class="ai-settings-section ai-configured-section">
          <h3 class="ai-configured-heading">当前生效的供应商</h3>
          <article class="ai-configured-card">
            <div class="ai-configured-head">
              <span class="ai-configured-mark" aria-hidden="true">${escapeHtml(provider.mark || 'API')}</span>
              <div class="ai-configured-title">
                <strong>${escapeHtml(label)}</strong>
                <small>${escapeHtml(authText)} · ${escapeHtml(endpoint)}</small>
              </div>
              <span class="ai-configured-badge is-${badgeTone}">${escapeHtml(badgeText)}</span>
            </div>
            <div class="ai-configured-models">
              <span>${models ? `预载模型：${escapeHtml(preview)}${models > 3 ? ` 等 ${models} 个` : ''}` : '尚未同步模型列表'}</span>
              <b>${models ? `${models} 个可用` : '--'}</b>
            </div>
            ${check.state === 'fail' && check.error ? `<p class="ai-configured-error">${icon('alert')}<span>${escapeHtml(check.error)}</span></p>` : ''}
            <p class="ai-configured-note">${escapeHtml(check.state === 'unknown'
              ? '联通状态需点击下方「测试连接」实测；后端不持久化历史检测结果，刷新页面后需重新测试。'
              : '联通状态与延迟来自本次会话内最近一次测试连接，非后端持久记录。')}</p>
          </article>
        </div>`;
  }

  /* 高级设置。排版按 demo 的三个「舱位」：运行时与接口 / 生成参数与工具授权 /
     系统提示词。控件与材质仍是我们自己的 Kit，没有照搬 demo 的 rgba 玻璃与 emoji。 */
  function settingsAdvancedSection(provider, apiBaseHelp) {
    /*
     * demo 2 的停用态：总开关关闭时把配置主体收起，换一条占位说明。
     * 早先这里的注释写了「关闭时折叠」，但代码从没实现 —— 字段照样全渲染。
     * 之所以要收起：LLM 关闭时这些参数保存了也不生效，摆满一屏可编辑字段
     * 会让人以为改了就有用。
     *
     * 注意仍然渲染总开关本身（在 settingsView 里），否则关掉之后就没有入口再打开。
     */
    if (!state.config.enabled) {
      return `<section class="ai-settings-chamber ai-dormant-chamber" data-ai-chamber="dormant">
          <div class="ai-dormant-body">
            ${icon('shield')}
            <strong>LLM 服务当前处于停用状态</strong>
            <small>打开上方开关后即可配置运行时端点、生成参数与系统提示词。停用时这些参数不会生效。</small>
          </div>
        </section>`;
    }
    const chambers = [
      {
        key: 'runtime', title: '运行时与接口',
        /*
         * API Base URL 已经移到「供应商设置」页（与 API Key 同一组凭据），
         * 这里**不再渲染第二个同名字段** —— 两个绑定同一个 `data-ai-config="api_base"`
         * 的输入框会让「哪个才是生效值」变成猜谜，也是用户要求「拿过来」的原意。
         */
        body: `<div class="ai-chamber-grid">
            <label class="ai-field"><span>默认模型</span><select data-ai-config="model">${modelOptions(state.config.model)}</select></label>
            <label class="ai-field"><span>最大输出 Token</span><input type="number" min="1" max="131072" step="1" value="${state.config.max_tokens}" data-ai-config="max_tokens"></label>
          </div>`
      },
      {
        key: 'generation', title: '生成参数与工具授权',
        body: `<div class="ai-chamber-grid">
            <label class="ai-field ai-range-field"><span>采样温度 <output data-ai-temperature-output>${Number(state.config.temperature).toFixed(1)}</output></span><input type="range" min="0" max="2" step="0.1" value="${state.config.temperature}" data-ai-config="temperature"><small>值越低，回答越聚焦且稳定；值越高，发散性越强</small></label>
            <label class="ai-field"><span>思考强度${reasoningDisabled() ? '' : `<em class="ai-field-tag">${escapeHtml(state.config.reasoning_api_shape)}</em>`}</span><select data-ai-config="reasoning_effort" ${reasoningDisabled() ? 'disabled' : ''}>${reasoningOptions(state.config.reasoning_effort)}</select><small>${reasoningDisabled() ? '当前模型不支持 reasoning_effort' : '决定模型在回答前投入的推理预算'}</small></label>
          </div>
          <label class="ai-field ai-field-wide"><span>工具授权策略</span><select data-ai-config="tool_policy">${TOOL_POLICIES.map(([value, label]) => `<option value="${value}" ${state.config.tool_policy === value ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select></label>`
      },
      {
        key: 'prompt', title: '系统提示词',
        body: `<label class="ai-field ai-field-wide"><textarea rows="5" placeholder="可选。为助手设定全局人设或行为准则。" data-ai-config="system_prompt">${escapeHtml(state.config.system_prompt)}</textarea></label>`
      }
    ];
    return chambers.map((chamber) => `<section class="ai-settings-chamber" data-ai-chamber="${chamber.key}"><h3>${escapeHtml(chamber.title)}</h3><div class="ai-chamber-body">${chamber.body}</div></section>`).join('');
  }

  function settingsFooter() {
    return `<div class="ai-settings-footer">
          <div class="ai-settings-status">
            ${connectionBadge()}
            <span>${state.notice ? escapeHtml(state.notice) : settingsDirty() ? '有未保存的修改' : '配置已同步'}</span>
          </div>
          <div class="ai-settings-actions">
            ${state.config.capabilities.provider_test ? `<button class="ai-secondary-button" type="button" data-ai-test-provider ${state.testingProvider || !credentialReady() ? 'disabled' : ''} ${credentialReady() ? '' : 'title="需要先启用 AI 并配置凭据"'}>${state.testingProvider ? icon('loader') : icon('link')}测试连接</button>` : ''}
            <button class="ai-secondary-button" type="button" data-ai-sync-models ${state.syncingModels ? 'disabled' : ''}>${state.syncingModels ? icon('loader') : icon('refresh')}${state.config.capabilities.provider_models_sync ? '同步模型' : '刷新模型列表'}</button>
          </div>
        </div>`;
  }

  function connectionBadge() {
    let stateName = 'off';
    let text = '未启用';
    if (state.loading) {
      stateName = 'checking';
      text = '读取中';
    } else if (state.config.auth_mode === 'oauth' && credentialReady()) {
      stateName = 'configured';
      text = 'OAuth 就绪';
    } else if (state.config.enabled && state.config.auth_mode === 'api_key' && state.config.api_key_set) {
      stateName = 'configured';
      text = '凭据就绪';
    } else if (state.config.enabled && state.config.auth_mode === 'oauth') {
      stateName = 'warning';
      text = oauthStatus()?.expired ? 'OAuth 已过期' : 'OAuth 未连接';
    } else if (state.config.enabled) {
      stateName = 'warning';
      text = '缺少 API Key';
    }
    const tone = stateName === 'configured' ? 'success' : stateName === 'checking' ? 'info' : stateName === 'warning' ? 'warning' : 'muted';
    return ui.statusBadgeMarkup?.(text, tone) || `<span>${escapeHtml(text)}</span>`;
  }

  function reasoningDisabled() {
    return state.loading || state.config.capabilities.reasoning_effort_supported === false;
  }

  function modelOptions(selected) {
    const models = uniqueModels([selected, ...state.models]);
    return models.map((model) => `<option value="${escapeHtml(model)}" ${model === selected ? 'selected' : ''}>${escapeHtml(model)}</option>`).join('');
  }

  function reasoningOptions(selected) {
    const provided = state.config.capabilities.reasoning_effort_values;
    const values = provided.length ? provided : ['auto', 'none', 'minimal', 'low', 'medium', 'high', 'xhigh'];
    return uniqueModels([selected, ...values]).map((value) => `<option value="${escapeHtml(value)}" ${value === selected ? 'selected' : ''}>${escapeHtml(REASONING_LABELS[value] || value)}</option>`).join('');
  }

  function toolPolicyOptions(selected) {
    return TOOL_POLICIES.map(([value, label]) => `<option value="${value}" ${value === selected ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('');
  }

  function loadingState(text) {
    return `<div class="ai-empty-state"><span class="ai-state-spinner">${icon('loader')}</span><strong>${escapeHtml(text)}</strong></div>`;
  }

  function bindEvents() {
    root.querySelector('.ai-settings-card')?.addEventListener('submit', (event) => event.preventDefault());
    const settingsTabs = root.querySelector('.ai-settings-tabs');
    if (settingsTabs) {
      const selectTab = (value) => {
        if (!value || value === state.settingsTab) return;
        if (!SETTINGS_TABS.some(([id]) => id === value)) return;
        state.settingsTab = value;
        state.settingsError = '';
        render();
      };
      settingsTabs.addEventListener('dwrt-tab-change', (event) => selectTab(event.detail?.value));
      settingsTabs.querySelectorAll('[data-ai-settings-tab]').forEach((button) => {
        button.addEventListener('click', () => selectTab(button.dataset.aiSettingsTab));
      });
    }
    root.querySelector('.ai-primary-tabs:not(.ai-settings-tabs)')?.addEventListener('dwrt-tab-change', (event) => {
      const value = event.detail?.value;
      if (!value || value === state.tab) return;
      setTab(value);
      state.notice = '';
      state.chatError = '';
      render();
    });
    root.querySelectorAll('[data-ai-new]').forEach((button) => button.addEventListener('click', startNewConversation));
    root.querySelector('[data-ai-add-toggle]')?.addEventListener('click', () => {
      state.addMenuOpen = !state.addMenuOpen;
      state.runtimeMenuOpen = false;
      render();
    });
    root.querySelector('[data-ai-runtime-toggle]')?.addEventListener('click', () => {
      state.runtimeMenuOpen = !state.runtimeMenuOpen;
      state.addMenuOpen = false;
      state.runtimePane = 'main';
      render();
    });
    root.querySelectorAll('[data-ai-runtime-pane]').forEach((button) => button.addEventListener('click', () => {
      state.runtimePane = button.dataset.aiRuntimePane || 'main';
      render();
    }));
    root.querySelectorAll('[data-ai-model-option]').forEach((button) => button.addEventListener('click', () => {
      state.current.model = button.dataset.aiModelOption;
      state.runtimeMenuOpen = false;
      state.runtimePane = 'main';
      render();
    }));
    root.querySelectorAll('[data-ai-effort-option]').forEach((button) => button.addEventListener('click', () => {
      state.current.reasoning_effort = button.dataset.aiEffortOption;
      state.runtimeMenuOpen = false;
      state.runtimePane = 'main';
      render();
    }));
    root.querySelectorAll('[data-ai-policy-option]').forEach((button) => button.addEventListener('click', () => {
      state.current.tool_policy = button.dataset.aiPolicyOption;
      state.runtimeMenuOpen = false;
      state.runtimePane = 'main';
      render();
    }));
    const prompt = root.querySelector('[data-ai-prompt]');
    if (prompt) {
      prompt.addEventListener('input', () => {
        state.prompt = prompt.value;
        autoSizePrompt(prompt);
      });
      prompt.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
          event.preventDefault();
          sendMessage();
        }
      });
    }
    root.querySelector('[data-ai-send]')?.addEventListener('click', sendMessage);
    root.querySelector('[data-ai-stop]')?.addEventListener('click', cancelStream);
    root.querySelectorAll('[data-ai-tool-approve]').forEach((button) => button.addEventListener('click', () => authorizeTool(button.dataset.aiToolApprove, true)));
    root.querySelectorAll('[data-ai-tool-deny]').forEach((button) => button.addEventListener('click', () => authorizeTool(button.dataset.aiToolDeny, false)));
    root.querySelector('[data-ai-clear-key]')?.addEventListener('click', () => {
      state.config.clear_api_key = !state.config.clear_api_key;
      if (state.config.clear_api_key) state.config.api_key_input = '';
      state.notice = '';
      render();
    });
    root.querySelectorAll('[data-ai-auth-mode]').forEach((button) => button.addEventListener('click', () => {
      const mode = button.dataset.aiAuthMode;
      if (mode !== 'api_key' && mode !== 'oauth') return;
      state.config.auth_mode = mode;
      state.notice = '';
      state.settingsError = '';
      if (mode === 'oauth') loadOAuthStatus(state.config.provider, { renderBefore: true });
      else render();
    }));
    root.querySelectorAll('[data-ai-oauth-input]').forEach((field) => field.addEventListener('input', (event) => {
      const provider = event.target.dataset.aiOauthProvider;
      const key = event.target.dataset.aiOauthInput;
      if (!state.oauth.inputs[provider] || !key) return;
      state.oauth.inputs[provider][key] = event.target.value;
      state.settingsError = '';
    }));
    root.querySelector('[data-ai-oauth-start]')?.addEventListener('click', startOAuth);
    root.querySelector('[data-ai-oauth-refresh]')?.addEventListener('click', refreshOAuth);
    root.querySelector('[data-ai-oauth-disconnect]')?.addEventListener('click', () => {
      state.oauth.confirmDisconnect = true;
      render();
    });
    root.querySelector('[data-ai-oauth-copy]')?.addEventListener('click', async (event) => {
      const value = firstText(event.currentTarget.dataset.aiOauthCopy);
      if (!value) return;
      try {
        await navigator.clipboard.writeText(value);
        state.notice = '验证码已复制';
      } catch (_) {
        state.notice = '无法访问剪贴板，请手动复制验证码';
      }
      render();
    });
    /*
     * 两个确认框（断开 OAuth / 移除供应商）共用 kit 的通用 accept/cancel 钩子，
     * 所以这里按当前打开的是哪一个来分发。同一时刻只会有一个为真。
     */
    root.querySelectorAll('[data-dwrt-confirm-cancel], [data-ai-oauth-disconnect-cancel], [data-ai-provider-remove-cancel], .dwrt-kit-modal-backdrop').forEach((button) => button.addEventListener('click', () => {
      state.oauth.confirmDisconnect = false;
      state.providerRemoveId = '';
      render();
    }));
    root.querySelectorAll('[data-dwrt-confirm-accept], [data-ai-oauth-disconnect-confirm], [data-ai-provider-remove-confirm]').forEach((button) => button.addEventListener('click', () => {
      if (state.providerRemoveId) {
        const id = state.providerRemoveId;
        state.providerRemoveId = '';
        runProviderAction(id, 'remove');
        return;
      }
      if (state.oauth.confirmDisconnect) disconnectOAuth();
    }));
    const fileInput = root.querySelector('[data-ai-file]');
    root.querySelector('[data-ai-add-file]')?.addEventListener('click', (event) => {
      state.addMenuOpen = false;
      event.currentTarget.closest('.ai-add-popover')?.remove();
      root.querySelector('.ai-add-control')?.classList.remove('is-open');
      root.querySelector('[data-ai-add-toggle]')?.setAttribute('aria-expanded', 'false');
      fileInput?.click();
    });
    root.querySelector('[data-ai-add-page]')?.addEventListener('click', () => {
      state.addMenuOpen = false;
      attachPageContext();
    });
    fileInput?.addEventListener('change', () => addAttachments(fileInput.files));
    root.querySelectorAll('[data-ai-remove-file]').forEach((button) => button.addEventListener('click', () => {
      state.attachments.splice(Number(button.dataset.aiRemoveFile), 1);
      render();
    }));
    const historySearch = root.querySelector('[data-ai-history-search]');
    historySearch?.addEventListener('input', (event) => {
      state.historyQuery = event.target.value;
      state.historyPage = 1;
      if (isGlobal) updateDrawerHistoryView();
      else updateHistoryRows();
    });
    bindHistoryItemEvents(root);
    root.querySelectorAll('[data-ai-provider]').forEach((button) => button.addEventListener('click', () => selectProvider(button.dataset.aiProvider)));
    root.querySelectorAll('[data-ai-config]').forEach((field) => {
      field.addEventListener('input', onConfigInput);
      field.addEventListener('change', onConfigInput);
    });
    root.querySelector('[data-ai-sync-models]')?.addEventListener('click', syncModels);
    root.querySelector('[data-ai-test-provider]')?.addEventListener('click', testProvider);
    root.querySelector('[data-dwrt-savebar-discard]')?.addEventListener('click', discardSettingsDraft);
    root.querySelector('[data-dwrt-savebar-save]')?.addEventListener('click', saveConfig);
    root.querySelectorAll('[data-ai-strategy]').forEach((button) => button.addEventListener('click', () => setDispatchStrategy(button.dataset.aiStrategy)));
    root.querySelector('[data-ai-provider-add]')?.addEventListener('click', addProvider);
    root.querySelectorAll('[data-ai-provider-test]').forEach((button) => button.addEventListener('click', () => runProviderAction(button.dataset.aiProviderTest, 'test')));
    root.querySelectorAll('[data-ai-provider-sync]').forEach((button) => button.addEventListener('click', () => runProviderAction(button.dataset.aiProviderSync, 'sync')));
    root.querySelectorAll('[data-ai-provider-primary]').forEach((button) => button.addEventListener('click', () => runProviderAction(button.dataset.aiProviderPrimary, 'primary')));
    root.querySelectorAll('[data-ai-provider-remove]').forEach((button) => button.addEventListener('click', () => {
      // 先开确认框，真正的 DELETE 在 confirm 分发里执行。
      state.providerRemoveId = firstText(button.dataset.aiProviderRemove);
      render();
    }));
  }

  function bindHistoryItemEvents(scope) {
    scope.querySelectorAll('[data-ai-history-page]').forEach((button) => button.addEventListener('click', () => {
      const page = Number(button.dataset.aiHistoryPage);
      if (!Number.isFinite(page) || page < 1) return;
      state.historyPage = page;
      render();
    }));
    scope.querySelectorAll('[data-ai-open-history]').forEach((row) => {
      row.addEventListener('click', (event) => {
        if (event.target.closest('[data-ai-delete-history]')) return;
        openHistory(row.dataset.aiOpenHistory);
      });
      row.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          openHistory(row.dataset.aiOpenHistory);
        }
      });
    });
    scope.querySelectorAll('[data-ai-delete-history]').forEach((button) => button.addEventListener('click', (event) => {
      event.stopPropagation();
      deleteHistory(button.dataset.aiDeleteHistory);
    }));
  }

  function bindGlobalEvents() {
    root.querySelector('[data-ai-history-toggle]')?.addEventListener('click', () => {
      const entering = state.tab !== 'history';
      state.tab = entering ? 'history' : 'chat';
      state.historyPage = 1;
      render();
      // 手动刷新按钮已删除，进入历史视图时顺带重取一次，保证列表不是打开即冻结的快照。
      if (entering && !state.historyLoading) refreshHistory();
    });
    root.querySelector('[data-ai-history-exit]')?.addEventListener('click', () => { state.tab = 'chat'; render(); });
    root.querySelectorAll('[data-ai-drawer-close]').forEach((button) => button.addEventListener('click', () => {
      touchActiveConversation();
      state.drawerOpen = false;
      state.addMenuOpen = false;
      state.runtimeMenuOpen = false;
      render();
    }));
    root.querySelector('[data-ai-orb-restore]')?.addEventListener('click', () => {
      state.orb.docked = false;
      const position = orbPosition();
      state.orb.x = position.x;
      state.orb.y = position.y;
      saveOrbState();
      render();
    });
    const orb = root.querySelector('[data-ai-orb]');
    orb?.addEventListener('pointerdown', beginOrbDrag);
    orb?.addEventListener('click', (event) => {
      if (performance.now() < state.orbClickBlockedUntil) { event.preventDefault(); return; }
      expireInactiveConversation();
      state.drawerOpen = true;
      state.tab = 'chat';
      touchActiveConversation();
      render();
    });
  }

  function beginOrbDrag(event) {
    if (event.button !== 0) return;
    const orb = event.currentTarget;
    const position = orbPosition();
    state.orbDrag = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, x: position.x, y: position.y, moved: false };
    orb.setPointerCapture?.(event.pointerId);
    orb.addEventListener('pointermove', moveOrbDrag);
    orb.addEventListener('pointerup', endOrbDrag);
    orb.addEventListener('pointercancel', endOrbDrag);
    event.preventDefault();
  }

  function moveOrbDrag(event) {
    const drag = state.orbDrag;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (Math.hypot(dx, dy) > 4) drag.moved = true;
    const size = 58;
    state.orb.x = Math.max(8, Math.min(window.innerWidth - size - 8, drag.x + dx));
    state.orb.y = Math.max(8, Math.min(window.innerHeight - size - 8, drag.y + dy));
    const orb = event.currentTarget;
    orb.style.setProperty('--ai-orb-x', `${state.orb.x}px`);
    orb.style.setProperty('--ai-orb-y', `${state.orb.y}px`);
  }

  function endOrbDrag(event) {
    const drag = state.orbDrag;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const orb = event.currentTarget;
    orb.releasePointerCapture?.(event.pointerId);
    orb.removeEventListener('pointermove', moveOrbDrag);
    orb.removeEventListener('pointerup', endOrbDrag);
    orb.removeEventListener('pointercancel', endOrbDrag);
    state.orbDrag = null;
    if (!drag.moved) return;
    state.orbClickBlockedUntil = performance.now() + 350;
    if (state.orb.x + 58 >= window.innerWidth - 22) state.orb.docked = true;
    saveOrbState();
    render();
  }

  function attachPageContext() {
    const value = typeof context.getPageContext === 'function' ? context.getPageContext() : defaultPageContext();
    const block = pageContextPrompt(value);
    state.prompt = state.prompt ? `${state.prompt}\n\n${block}` : block;
    const prompt = root.querySelector('[data-ai-prompt]');
    if (prompt) {
      prompt.value = state.prompt;
      autoSizePrompt(prompt);
      sendMessage();
      return;
    }
    render();
    requestAnimationFrame(() => sendMessage());
  }

  function defaultPageContext() {
    const main = document.querySelector('#consoleMain');
    return { title: document.title, route: window.location.hash, text: firstText(main?.innerText).slice(0, 8000) };
  }

  function pageContextPrompt(value = {}) {
    const title = firstText(value.title, '当前页面');
    const route = firstText(value.route, window.location.hash);
    const text = firstText(value.text).slice(0, 8000);
    return `请基于我当前打开的页面指导或代替我完成操作。\n页面：${title}\n路由：${route}\n页面内容：\n${text || '当前页面没有可读取的文本内容。'}`;
  }

  function startNewConversation() {
    clearActiveConversation();
    state.current = newConversation();
    state.current.model = state.config.model;
    state.current.reasoning_effort = state.config.reasoning_effort;
    state.current.tool_policy = state.config.tool_policy;
    state.prompt = '';
    state.attachments = [];
    state.chatError = '';
    state.notice = '';
    state.addMenuOpen = false;
    state.runtimeMenuOpen = false;
    state.runtimePane = 'main';
    state.shouldStickChat = true;
    clearToolRuntime();
    state.stream.responseId = '';
    state.stream.messageId = '';
    setTab('chat');
    render();
    requestAnimationFrame(() => root.querySelector('[data-ai-prompt]')?.focus());
  }

  function autoSizePrompt(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(132, Math.max(24, textarea.scrollHeight))}px`;
  }

  async function addAttachments(fileList) {
    const files = Array.from(fileList || []);
    const accepted = [];
    let error = '';
    for (const file of files) {
      if (file.size > 512 * 1024) {
        error = `${file.name} 超过 512 KB`;
        continue;
      }
      try {
        accepted.push({ name: file.name, size: file.size, type: file.type || 'text/plain', content: await file.text() });
      } catch (_) {
        error = `${file.name} 无法读取`;
      }
    }
    state.attachments = [...state.attachments, ...accepted].slice(0, 8);
    state.chatError = error;
    render();
    requestAnimationFrame(() => root.querySelector('[data-ai-prompt]')?.focus());
  }

  async function sendMessage() {
    if (state.sending || !credentialReady()) return;
    const prompt = root.querySelector('[data-ai-prompt]');
    const content = firstText(prompt?.value);
    if (content === '/new') {
      startNewConversation();
      return;
    }
    if (!content && !state.attachments.length) return;
    const now = Date.now();
    const selectedAttachments = state.attachments.map(({ name, size, type, content: fileContent }) => ({ name, size, type, content: fileContent }));
    const attachments = selectedAttachments.map(({ name, size, type }) => ({ name, size, type }));
    const userMessage = { id: `user-${now}`, role: 'user', content: content || '请分析附件。', created_at: now, attachments };
    state.current.messages.push(userMessage);
    state.current.model = currentModel();
    state.current.reasoning_effort = currentEffort();
    state.current.tool_policy = currentToolPolicy();
    conversationId();
    touchActiveConversation();
    state.attachments = [];
    state.prompt = '';
    state.sending = true;
    state.chatError = '';
    state.notice = '';
    state.shouldStickChat = true;
    clearToolRuntime();
    state.stream.responseId = '';
    state.stream.messageId = '';
    render();
    try {
      let outboundAttachments = selectedAttachments;
      if (state.config.capabilities.attachment_ids && selectedAttachments.length) {
        const uploadEndpoint = state.config.capabilities.attachment_upload_endpoint || ENDPOINTS.attachments;
        const uploaded = await Promise.all(selectedAttachments.map(async ({ name, size, type, content: fileContent }) => {
          const result = await postJson(uploadEndpoint, { name, size, type, content: fileContent });
          const data = unwrap(result);
          if (!firstText(data.attachment_id)) throw new Error(`${name} 上传后缺少 attachment_id`);
          return {
            attachment_id: firstText(data.attachment_id),
            name: firstText(data.name, name),
            size: firstNumber(data.size, size),
            type: firstText(data.type, type)
          };
        }));
        userMessage.attachments = uploaded;
        outboundAttachments = uploaded;
      }
      const payload = {
        conversation_id: conversationId(),
        model: currentModel(),
        reasoning_effort: currentEffort(),
        tool_policy: currentToolPolicy(),
        messages: state.current.messages
          .filter((item) => !item.streaming)
          .map(({ role, content: text }) => ({ role, content: text })),
        attachments: outboundAttachments
      };
      let streamed = false;
      if (streamingReady()) {
        state.stream.active = true;
        render();
        try {
          await streamRequest(streamEndpoint(), payload, {
            onEvent: (name, eventPayload) => handleStreamEvent(name, eventPayload)
          });
          streamed = true;
        } catch (error) {
          if (error?.name === 'AbortError') streamed = true;
          else if (!error?.notStream) throw error;
        } finally {
          state.stream.active = false;
          state.stream.controller = null;
        }
      }
      if (!streamed) {
        const result = await postJson(ENDPOINTS.chat, payload);
        if (!state.mounted) return;
        const data = unwrap(result);
        state.current.id = firstText(data.conversation_id, data.conversation?.id, state.current.id);
        state.current.title = firstText(data.conversation_title, data.title, data.conversation?.title, state.current.title);
        touchActiveConversation();
        asArray(data.tool_executions).forEach(recordToolActivity);
        const pending = asArray(data.pending_authorizations).map(normalizeToolExecution).filter((item) => item.auth_id > 0);
        state.pendingAuthorizations = pending;
        if (pending.length) {
          state.resume = {
            token: firstText(data.resume_token),
            expires_at: firstNumber(data.resume_expires_at, 0),
            endpoint: firstText(data.resume_endpoint, ENDPOINTS.toolResume),
            stream_endpoint: firstText(data.resume_stream_endpoint, ENDPOINTS.toolResumeStream)
          };
        }
        const reply = extractAssistantReply(data);
        if (!reply && !pending.length) {
          const notReady = firstText(data.message).toLowerCase().includes('integration pending') || data.status === 'ready';
          throw new Error(notReady ? '模型运行时尚未接入，后端未生成回答' : firstText(data.error, '后端未返回 AI 回答'));
        }
        if (reply) state.current.messages.push({ id: `assistant-${Date.now()}`, role: 'assistant', content: reply, created_at: Date.now(), attachments: [] });
        state.current.usage = data.usage && typeof data.usage === 'object' ? data.usage : state.current.usage;
      }
      if (!state.mounted) return;
      finishStreamingMessage();
      if (state.pendingAuthorizations.length) {
        state.notice = '模型请求执行工具，请确认授权';
        await persistCurrentConversation().catch(() => {});
      } else {
        await persistCurrentConversation();
        state.notice = '对话已保存';
      }
    } catch (error) {
      if (error?.name !== 'AbortError') state.chatError = error?.message || 'AI 请求失败';
      finishStreamingMessage();
      await persistCurrentConversation().catch(() => {});
    } finally {
      if (!state.mounted) return;
      state.sending = false;
      state.stream.active = false;
      state.stream.controller = null;
      state.shouldStickChat = true;
      render();
      requestAnimationFrame(() => root.querySelector('[data-ai-prompt]')?.focus());
    }
  }

  function extractAssistantReply(data = {}) {
    const direct = firstText(data.reply, data.response, data.output_text, data.assistant?.content, data.assistant?.text);
    if (direct) return direct;
    const choices = asArray(data.choices);
    return firstText(choices[0]?.message?.content, choices[0]?.text);
  }

  async function persistCurrentConversation() {
    const persistable = state.current.messages.filter((item) => !item.streaming && firstText(item.content));
    if (!persistable.length) return;
    const result = await postJson(ENDPOINTS.history, {
      id: conversationId(),
      title: conversationTitle(),
      model: currentModel(),
      reasoning_effort: currentEffort(),
      tool_policy: currentToolPolicy(),
      usage: state.current.usage || {},
      messages: persistable.map(({ id: message_id, role, content, created_at, attachments }) => ({
        message_id,
        role,
        content,
        created_at: Math.floor(normalizeTimestamp(created_at) / 1000),
        attachments: asArray(attachments).map(({ attachment_id, name, type, size }) => ({ attachment_id, name, type, size }))
      }))
    });
    const data = unwrap(result);
    state.current.id = firstText(data.id, state.current.id);
    state.current.title = firstText(data.conversation_title, data.title, data.conversation?.title, state.current.title);
    touchActiveConversation();
    await refreshHistory(false);
  }

  async function refreshHistory(shouldRender = true) {
    state.historyLoading = true;
    state.historyError = '';
    if (shouldRender) render();
    const result = await fetchApi('ai-history', `${ENDPOINTS.history}?limit=100&offset=0`);
    if (!state.mounted) return;
    if (result?.ok) state.history = normalizeHistory(result.data);
    else state.historyError = result?.error?.message || '无法读取历史对话';
    state.historyLoading = false;
    if (shouldRender && document.activeElement?.matches('[data-ai-history-search]')) {
      if (isGlobal) updateDrawerHistoryView();
      else updateHistoryView();
    }
    else if (shouldRender) render();
  }

  async function openHistory(id, options = {}) {
    if (!id || state.loadingConversation) return;
    state.loadingConversation = id;
    if (!options.quiet) render();
    const result = await fetchApi('ai-history-detail', `${ENDPOINTS.history}/${encodeURIComponent(id)}`);
    if (!state.mounted) return;
    state.loadingConversation = '';
    if (!result?.ok) {
      state.historyError = result?.error?.message || '无法读取该对话';
      render();
      return;
    }
    state.current = normalizeConversation(result.data);
    touchActiveConversation(state.current.id);
    state.attachments = [];
    state.chatError = '';
    state.notice = '';
    state.shouldStickChat = true;
    clearToolRuntime();
    state.stream.responseId = '';
    state.stream.messageId = '';
    setTab('chat');
    render();
  }

  async function deleteHistory(id) {
    if (!id || state.deletingConversation) return;
    state.deletingConversation = id;
    render();
    try {
      await requestJson(`${ENDPOINTS.history}/${encodeURIComponent(id)}`, { method: 'DELETE' });
      state.history = state.history.filter((item) => item.id !== id);
      if (state.current.id === id) {
        clearActiveConversation();
        state.current = newConversation();
      }
    } catch (error) {
      state.historyError = error?.message || '删除失败';
    }
    state.deletingConversation = '';
    render();
  }

  function updateHistoryRows() {
    const tbody = root.querySelector('.ai-history-table tbody');
    const count = root.querySelector('.ai-history-toolbar .dwrt-kit-table-count');
    if (!tbody) return;
    const rows = filteredHistory();
    tbody.innerHTML = rows.length ? rows.map(historyRow).join('') : `<tr><td colspan="6" class="dwrt-kit-table-empty">${state.historyQuery ? '没有匹配的对话' : '暂无历史对话'}</td></tr>`;
    if (count) count.textContent = `${formatInteger(rows.length)} 条`;
    tbody.querySelectorAll('[data-ai-open-history]').forEach((row) => row.addEventListener('click', (event) => {
      if (!event.target.closest('[data-ai-delete-history]')) openHistory(row.dataset.aiOpenHistory);
    }));
    tbody.querySelectorAll('[data-ai-delete-history]').forEach((button) => button.addEventListener('click', (event) => {
      event.stopPropagation();
      deleteHistory(button.dataset.aiDeleteHistory);
    }));
  }

  function updateHistoryView() {
    const status = root.querySelector('.ai-history-toolbar .dwrt-kit-table-title span');
    if (status) status.textContent = state.historyLoading ? '正在读取' : state.historyError || '按最近更新时间排序';
    updateHistoryRows();
  }

  function updateDrawerHistoryView() {
    const history = root.querySelector('.ai-drawer-history');
    const list = history?.querySelector('.ai-drawer-history-list');
    const pagination = history?.querySelector('.ai-history-pagination');
    if (!history || !list || !pagination) return;
    const rows = filteredHistory();
    const totalPages = Math.max(1, Math.ceil(rows.length / state.historyPageSize));
    const page = Math.max(1, Math.min(totalPages, state.historyPage));
    state.historyPage = page;
    const pageRows = rows.slice((page - 1) * state.historyPageSize, page * state.historyPageSize);
    list.innerHTML = state.historyLoading
      ? loadingState('正在读取历史对话')
      : pageRows.length
        ? pageRows.map(historyStrip).join('')
        : `<div class="ai-empty-state"><strong>${state.historyQuery ? '没有匹配的对话' : '暂无历史对话'}</strong></div>`;
    pagination.innerHTML = `<button type="button" data-ai-history-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>上一页</button><span>${page} / ${totalPages}</span><button type="button" data-ai-history-page="${page + 1}" ${page >= totalPages ? 'disabled' : ''}>下一页</button>`;
    bindHistoryItemEvents(history);
  }

  function selectProvider(id) {
    const next = PROVIDERS.find((item) => item.id === id);
    if (!next || state.config.provider === id) return;
    state.config.provider = id;
    if (!state.config.api_base || PROVIDERS.some((item) => item.base === state.config.api_base)) state.config.api_base = next.base;
    state.oauth.flow = null;
    state.oauth.confirmDisconnect = false;
    if (state.config.auth_mode === 'oauth' && oauthProvider(id)?.supported !== true) state.config.auth_mode = 'api_key';
    state.notice = '';
    render();
    if (state.config.auth_mode === 'oauth') loadOAuthStatus(id);
  }

  function onConfigInput(event) {
    const key = event.target.dataset.aiConfig;
    if (!key) return;
    if (event.target.type === 'checkbox') state.config[key] = event.target.checked;
    else if (key === 'temperature') state.config[key] = Number(event.target.value);
    else if (key === 'max_tokens') state.config[key] = Math.max(1, Math.round(Number(event.target.value) || 1));
    else state.config[key] = event.target.value;
    state.notice = '';
    if (key === 'temperature') {
      const output = root.querySelector('[data-ai-temperature-output]');
      if (output) output.textContent = Number(state.config.temperature).toFixed(1);
    }
    const status = root.querySelector('.ai-settings-status > span:last-child');
    if (status) status.textContent = settingsDirty() ? '有未保存的修改' : '配置已同步';
    render();
  }

  async function syncModels() {
    if (state.syncingModels) return;
    state.syncingModels = true;
    state.settingsError = '';
    render();
    try {
      if (state.config.capabilities.provider_models_sync) {
        const synced = unwrap(await postJson(ENDPOINTS.modelsSync, { provider: state.config.provider }));
        if (!state.mounted) return;
        const models = uniqueModels(asArray(synced.models || synced));
        if (models.length) {
          state.models = models;
          state.notice = `已从提供商同步 ${models.length} 个模型`;
          state.syncingModels = false;
          render();
          return;
        }
      }
      const result = await fetchApi('ai-models', ENDPOINTS.models);
      if (!state.mounted) return;
      if (result?.ok) {
        state.models = uniqueModels(asArray(unwrap(result.data).models || unwrap(result.data)));
        state.notice = state.config.capabilities.provider_models_sync
          ? `已读取 ${state.models.length} 个模型`
          : `已读取 ${state.models.length} 个模型（后端未开放提供商同步）`;
      } else {
        state.settingsError = result?.error?.message || '模型列表读取失败';
      }
    } catch (error) {
      if (!state.mounted) return;
      state.settingsError = error?.message || '模型同步失败';
    }
    if (!state.mounted) return;
    state.syncingModels = false;
    render();
  }

  async function testProvider() {
    if (state.testingProvider || !state.config.capabilities.provider_test) return;
    state.testingProvider = true;
    state.settingsError = '';
    state.notice = '';
    render();
    try {
      const data = unwrap(await postJson(ENDPOINTS.providerTest, { provider: state.config.provider }));
      if (!state.mounted) return;
      const latency = firstNumber(data.latency_ms, data.latency, 0);
      const model = firstText(data.model, currentModel());
      state.providerCheck = {
        state: data.ok === false ? 'fail' : 'ok',
        latency: Math.round(latency) || 0,
        model,
        error: data.ok === false ? apiErrorText(data, '提供商未返回成功状态') : '',
        at: Date.now()
      };
      state.notice = data.ok === false
        ? `连接测试失败：${apiErrorText(data, '提供商未返回成功状态')}`
        : `连接正常${model ? `（${model}）` : ''}${latency ? ` · ${Math.round(latency)} ms` : ''}`;
    } catch (error) {
      if (!state.mounted) return;
      state.providerCheck = { state: 'fail', latency: 0, model: '', error: error?.message || '连接测试失败', at: Date.now() };
      state.settingsError = error?.message || '连接测试失败';
    }
    if (!state.mounted) return;
    state.testingProvider = false;
    render();
  }

  /* 策略 pill 只改草稿；持久写由页面统一 Savebar 触发。 */
  function setDispatchStrategy(strategy) {
    const id = firstText(strategy);
    if (!id || state.saving) return;
    if (state.dispatch.draftStrategy === id) return;
    if (!dispatchStrategies().includes(id)) return;
    state.dispatch.draftStrategy = id;
    state.settingsError = '';
    state.notice = '';
    render();
  }

  function discardSettingsDraft() {
    if (state.saving) return;
    if (state.baselineConfig) state.config = JSON.parse(JSON.stringify(state.baselineConfig));
    state.dispatch.draftStrategy = state.dispatch.baselineStrategy;
    state.settingsError = '';
    state.notice = '';
    render();
  }

  function providerById(id) {
    return state.providers.items.find((item) => item.id === id) || null;
  }

  /* 列表内单条供应商的动作：测试 / 拉模型 / 设为主通道 / 移除。 */
  async function runProviderAction(id, action) {
    const providerId = firstText(id);
    const item = providerById(providerId);
    if (!providerId || !item || state.providerBusy.id) return;
    state.providerBusy = { id: providerId, action };
    state.settingsError = '';
    state.notice = '';
    render();
    const label = firstText(item.display_name, oauthProviderLabel(item.provider));
    const base = `${ENDPOINTS.providers}/${encodeURIComponent(providerId)}`;
    try {
      if (action === 'test') {
        const data = unwrap(await requestJson(`${base}/test`, { method: 'POST' }));
        if (!state.mounted) return;
        const latency = data.latency_ms === null || data.latency_ms === undefined ? null : Math.round(firstNumber(data.latency_ms, 0));
        state.notice = data.ok === false
          ? `${label} 连接失败：${firstText(data.error_kind, apiErrorText(data, '未返回成功状态'))}`
          : `${label} 连接正常${latency === null ? '' : ` · ${latency} ms`}`;
      } else if (action === 'sync') {
        const data = unwrap(await requestJson(`${base}/models/sync`, { method: 'POST' }));
        if (!state.mounted) return;
        const models = asArray(data.models || data);
        // 很多 OpenAI 兼容反代不实现 /v1/models，此时后端给 invalid_response。
        state.notice = models.length
          ? `${label} 已同步 ${models.length} 个模型`
          : `${label} 未返回模型列表，可在高级设置手工填写模型名`;
      } else if (action === 'primary') {
        // PATCH 不带的字段保持原值（契约第五、七节），所以只提交 role。
        await requestJson(base, { method: 'PATCH', body: JSON.stringify({ role: 'primary' }) });
        if (!state.mounted) return;
        state.notice = `${label} 已设为主通道`;
      } else if (action === 'remove') {
        await requestJson(base, { method: 'DELETE' });
        if (!state.mounted) return;
        state.notice = `${label} 已移除`;
      }
      state.providerBusy = { id: '', action: '' };
      await Promise.all([loadProviders({ render: false }), loadDispatchPolicy({ render: false })]);
    } catch (error) {
      if (!state.mounted) return;
      state.providerBusy = { id: '', action: '' };
      const code = firstText(error?.payload?.error?.code, error?.payload?.code);
      if (code === 'provider_in_use') state.settingsError = `${label} 正被进行中的会话占用，请稍后再移除。`;
      else if (code === 'provider_not_found') {
        state.settingsError = `${label} 已不存在，列表已刷新。`;
        await loadProviders({ render: false });
      } else state.settingsError = classifyApiFailure(error, `${label} 操作`, 'write').message;
    }
    if (!state.mounted) return;
    render();
  }

  /*
   * 「添加到已配置列表」：把上方选中的品牌与凭据提交为一条新供应商。
   * 列表为空时第一条自动设为主通道，否则默认备用（契约允许唯一主）。
   */
  async function addProvider() {
    if (state.providerBusy.id || state.providerBusy.action) return;
    const apiKey = state.config.api_key_input.trim();
    if (state.config.auth_mode !== 'oauth' && !apiKey) {
      state.settingsError = '请先填写该供应商的 API Key，再添加到列表。';
      render();
      return;
    }
    state.providerBusy = { id: '', action: 'add' };
    state.settingsError = '';
    state.notice = '';
    render();
    const definition = providerDefinition();
    const label = oauthProviderLabel(state.config.provider);
    try {
      await requestJson(ENDPOINTS.providers, {
        method: 'POST',
        body: JSON.stringify({
          provider: state.config.provider,
          display_name: label,
          api_base: firstText(state.config.api_base, definition.base),
          auth_mode: state.config.auth_mode,
          ...(state.config.auth_mode === 'oauth' ? {} : { api_key: apiKey }),
          default_model: state.config.model,
          role: state.providers.items.length ? 'standby' : 'primary',
          enabled: true
        })
      });
      if (!state.mounted) return;
      state.providerBusy = { id: '', action: '' };
      state.config.api_key_input = '';
      state.notice = `${label} 已加入已配置列表`;
      await Promise.all([loadProviders({ render: false }), loadDispatchPolicy({ render: false })]);
    } catch (error) {
      if (!state.mounted) return;
      state.providerBusy = { id: '', action: '' };
      const code = firstText(error?.payload?.error?.code, error?.payload?.code);
      if (code === 'invalid_provider_kind') state.settingsError = '后端不接受该供应商类型，请换一个品牌或使用 OpenAI 兼容。';
      else if (code === 'capability_disabled') state.settingsError = '后端当前关闭了 AI 写入能力，无法新增供应商。';
      else state.settingsError = classifyApiFailure(error, '新增供应商', 'write').message;
    }
    if (!state.mounted) return;
    render();
  }

  async function saveConfig() {
    const saveMainConfig = configDirty();
    const saveDispatch = dispatchDirty();
    if (state.saving || (!saveMainConfig && !saveDispatch)) return;
    state.saving = true;
    state.settingsError = '';
    state.notice = '';
    render();
    const apiKey = state.config.api_key_input.trim();
    const results = [];
    if (saveMainConfig) {
      try {
        await postJson(ENDPOINTS.config, {
        provider: state.config.provider,
        api_base: state.config.api_base.trim(),
        ...(apiKey ? { api_key: apiKey } : {}),
        clear_api_key: Boolean(state.config.clear_api_key),
        auth_mode: state.config.auth_mode,
        model: state.config.model,
        temperature: Number(state.config.temperature),
        max_tokens: Number(state.config.max_tokens),
        system_prompt: state.config.system_prompt,
        tool_policy: state.config.tool_policy,
        enabled: Boolean(state.config.enabled),
        reasoning_effort: state.config.reasoning_effort,
        reasoning_api_shape: state.config.reasoning_api_shape
        });
        const result = await fetchApi('ai-config', ENDPOINTS.config);
        if (!result?.ok) throw result?.error || new Error('保存后无法读取配置');
        const canonical = normalizeConfig(result.data);
        if (apiKey && !canonical.api_key_set) throw new Error('保存后回读未确认 API Key 已写入');
        if (state.config.clear_api_key && canonical.api_key_set) throw new Error('保存后回读仍显示 API Key 已保存');
        state.config = canonical;
        state.oauth.available = state.config.oauth.available;
        state.oauth.catalog = state.config.oauth.catalog;
        if (state.config.auth_mode === 'oauth') await loadOAuthStatus(state.config.provider, { quiet: true });
        markBaseline();
        notifyConfigUpdated();
        results.push('主配置已保存');
      } catch (error) {
        state.settingsError = `主配置未保存：${firstText(error?.message, '保存失败')}`;
      }
    }
    if (saveDispatch) {
      const wanted = state.dispatch.draftStrategy;
      try {
        await requestJson(ENDPOINTS.dispatchPolicy, { method: 'PUT', body: JSON.stringify({ strategy: wanted }) });
        const canonical = normalizeDispatchPolicy(await requestJson(ENDPOINTS.dispatchPolicy));
        if (canonical.strategy !== wanted) throw new Error('保存后回读与草稿不一致');
        state.dispatch.policy = canonical;
        state.dispatch.baselineStrategy = canonical.strategy;
        state.dispatch.draftStrategy = canonical.strategy;
        state.dispatch.loaded = true;
        state.dispatch.error = '';
        results.push('调度策略已保存');
      } catch (error) {
        const code = firstText(error?.payload?.error?.code, error?.payload?.code);
        const status = Math.round(firstNumber(error?.status, 0));
        const message = status === 422 || code === 'primary_required'
          ? '请先把一个供应商设为主通道，再切换到单供应商策略'
          : classifyApiFailure(error, '调度策略', 'write').message;
        state.settingsError = `${state.settingsError ? `${state.settingsError}；` : ''}调度策略未保存：${message}`;
      }
    }
    state.notice = results.length ? results.join('，') : '';
    state.saving = false;
    render();
  }

  async function requestJson(url, options = {}) {
    const response = await sessionFetch(`${url}${url.includes('?') ? '&' : '?'}v=${encodeURIComponent(VERSION)}`, {
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { ...(api.authHeaders ? api.authHeaders() : {}), ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) },
      ...options
    });
    const text = await response.text();
    let json = {};
    if (text) {
      try { json = JSON.parse(text); } catch (_) { throw new Error('后端返回了无效 JSON'); }
    }
    if (!response.ok || json?.ok === false) {
      const error = new Error(apiErrorText(json, `${response.status}`));
      error.status = response.status;
      error.payload = json;
      throw error;
    }
    return json;
  }

  function postJson(url, body) {
    return requestJson(url, { method: 'POST', body: JSON.stringify(body || {}) });
  }

  function captureViewState() {
    if (!root) return null;
    root.querySelectorAll('[data-ai-scroll]').forEach((element) => {
      state.scrollPositions[element.dataset.aiScroll] = { top: element.scrollTop, left: element.scrollLeft };
    });
    return { scroll: { ...state.scrollPositions } };
  }

  function restoreViewState(snapshot) {
    requestAnimationFrame(() => {
      if (!state.mounted || !root) return;
      root.querySelectorAll('[data-ai-scroll]').forEach((element) => {
        const value = snapshot?.scroll?.[element.dataset.aiScroll] || state.scrollPositions[element.dataset.aiScroll];
        if (value) {
          element.scrollTop = value.top;
          element.scrollLeft = value.left;
        }
      });
      const chat = root.querySelector('[data-ai-scroll="chat"]');
      if (chat && state.shouldStickChat) {
        chat.scrollTop = chat.scrollHeight;
        state.shouldStickChat = false;
      }
    });
  }

  function formatRelativeTime(value) {
    const timestamp = normalizeTimestamp(value);
    if (!timestamp) return '--';
    const delta = Date.now() - timestamp;
    if (delta < 60000) return '刚刚';
    if (delta < 3600000) return `${Math.floor(delta / 60000)} 分钟前`;
    if (delta < 86400000) return `${Math.floor(delta / 3600000)} 小时前`;
    if (delta < 604800000) return `${Math.floor(delta / 86400000)} 天前`;
    return new Intl.DateTimeFormat('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).format(timestamp);
  }

  function formatMessageTime(value) {
    const timestamp = normalizeTimestamp(value);
    if (!timestamp) return '';
    return new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit' }).format(timestamp);
  }

  function formatFileSize(value) {
    const size = Number(value) || 0;
    if (size < 1024) return `${size} B`;
    return `${(size / 1024).toFixed(size > 10240 ? 0 : 1)} KB`;
  }

  function icon(name) {
    const paths = {
      plus: '<path d="M12 5v14M5 12h14"/>',
      back: '<path d="m15 18-6-6 6-6"/>',
      'chevron-down': '<path d="m6 9 6 6 6-6"/>',
      'chevron-right': '<path d="m9 18 6-6-6-6"/>',
      'new-chat': '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z"/>',
      paperclip: '<path d="m21.4 11.6-8.9 8.9a6 6 0 0 1-8.5-8.5l9.6-9.6a4 4 0 0 1 5.7 5.7l-9.6 9.6a2 2 0 0 1-2.8-2.8l8.9-8.9"/>',
      'page-add': '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M12 18v-6M9 15h6"/>',
      shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
      send: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
      stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
      loader: '<path d="M21 12a9 9 0 1 1-6.2-8.6"/>',
      alert: '<path d="M10.3 2.9 1.8 17a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 2.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/>',
      check: '<path d="m20 6-11 11-5-5"/>',
      file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>',
      close: '<path d="m18 6-12 12M6 6l12 12"/>',
      search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
      refresh: '<path d="M20 6v5h-5M4 18v-5h5"/><path d="M18.5 9A7 7 0 0 0 6 5.5L4 8m2 7.5A7 7 0 0 0 18 18l2-2.5"/>',
      trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v6M14 11v6"/>',
      save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
      key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15 8l3 3M18 5l3 3"/>',
      link: '<path d="M10 13a5 5 0 0 0 7.1.1l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.1-.1l-2 2A5 5 0 0 0 12 20l1.1-1.1"/>',
      copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
      external: '<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
      spark: '<path d="m12 3-1.4 3.6a3 3 0 0 1-1.7 1.7L5.3 9.7l3.6 1.4a3 3 0 0 1 1.7 1.7L12 16.4l1.4-3.6a3 3 0 0 1 1.7-1.7l3.6-1.4-3.6-1.4a3 3 0 0 1-1.7-1.7Z"/><path d="m19 17-.5 1.3a1.5 1.5 0 0 1-.8.8l-1.3.5 1.3.5a1.5 1.5 0 0 1 .8.8L19 22l.5-1.1a1.5 1.5 0 0 1 .8-.8l1.3-.5-1.3-.5a1.5 1.5 0 0 1-.8-.8Z"/>'
    };
    return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.spark}</svg>`;
  }

  render();
  loadInitial();

  return {
    open(options = {}) {
      if (!isGlobal) return;
      const prompt = firstText(options.prompt).slice(0, 12000);
      expireInactiveConversation();
      state.drawerOpen = true;
      state.tab = options.history ? 'history' : 'chat';
      touchActiveConversation();
      if (prompt) {
        state.prompt = prompt;
        state.initialAutoSend = Boolean(options.autoSend);
      }
      render();
      if (prompt && state.initialAutoSend && !state.loading && credentialReady()) {
        state.initialAutoSend = false;
        sendMessage();
      }
    },
    close() {
      if (!isGlobal) return;
      touchActiveConversation();
      state.drawerOpen = false;
      render();
    },
    unmount() {
      state.mounted = false;
      state.seq += 1;
      try { state.stream.controller?.abort(); } catch (_) {}
      state.stream.controller = null;
      clearOAuthPollTimer();
      window.removeEventListener('message', receiveOAuthCompletion);
      window.removeEventListener('dwrt:ai-config-updated', receiveConfigUpdated);
      window.removeEventListener('dwrt:ai-oauth-updated', receiveOAuthUpdated);
      if (isGlobal) {
        window.removeEventListener('dwrt:ai-initial-request', receiveInitialRequest);
        window.removeEventListener('resize', handleViewportResize);
        document.removeEventListener('pointerdown', handleGlobalPointerDown);
        wallpaper?.removeEventListener('load', handleWallpaperChange);
        wallpaperObserver?.disconnect();
      }
      if (root) root.classList.remove(MODULE_CLASS);
    }
  };
}
